#ifndef __DEFINITION_LIST_H__
#define __DEFINITION_LIST_H__

#include "initializer.h"

/*
该文件用于定义全局变量以及各种重定义各种函数名字等
*/

//************************************************************************************************
//****>>>全局变量定义组<<<************************************************************************
//************************************************************************************************
//*******工作进程*********************************************************************************
extern uint8_t 	Process;							//进程
extern uint8_t 	Area;								//工作区域区域
extern int8_t 	Count;								//数量


/*************************************************************************************************
Process:开始阶段为0、A区域为1、B区域为2、C区域为3、D区域为4
			左转弯为5、右转弯为6、结束阶段为7；D区倒退阶段8;
			倒退左转10；倒退右转11；
Situat[3][6]:用于存放旱情信息

*************************************************************************************************/
//************************************************************************************************
//*******旱情信息数组*****************************************************************************
extern uint16_t Situation_Receive[3][6];				//接收到的旱情数组（用无线传输的ABC区）
extern uint8_t Situation_A[6];							//提取A区信息
extern uint8_t Situation_B[6];							//提取B区信息
extern uint8_t Situation_C[6];							//提取C区信息
extern uint8_t Situation_D[6];							//接收到的D区信息（用无线传输的D区）

extern uint8_t Situat_D;								//车上摄像头识别到的D区旱情

#define		Situat		Situation_Receive
#define		Situat_Dd 	Situation_D
//************************************************************************************************
//*******陀螺仪返回值*****************************************************************************
extern int16_t Angle_X_Values;						//获取到的X值
extern int16_t Angle_Y_Values;						//获取到的Y值
extern int16_t Angle_Z_Values;						//获取到的Z值

extern int16_t Initial_Angle_X;						//由于记录初值的X值
extern int16_t Initial_Angle_Y;						//由于记录初值的Y值
extern int16_t Initial_Angle_Z;						//由于记录初值的Z值

#define 	X			Angle_X_Values
#define 	Y			Angle_Y_Values
#define 	Z			Angle_Z_Values

#define		Initial_X 	Initial_Angle_X
#define		Initial_Y 	Initial_Angle_Y
#define		Initial_Z 	Initial_Angle_Z

extern uint16_t Left_Angle;
extern uint16_t Right_Angle;

extern uint16_t Left_Angle_Last;
extern uint16_t Right_Angle_Last;


//************************************************************************************************
//*******电机和舵机PWM输出变量********************************************************************
extern uint16_t Pwm_Left_Wheel;						//左轮PWM
extern uint16_t Pwm_Right_Wheel;						//右轮PWM

#define 	Pwm_1		Pwm_Left_Wheel
#define 	Pwm_2		Pwm_Right_Wheel

extern uint16_t Pwm_Left_Steering_Engine;			//左舵机PWM
extern uint16_t Pwm_Right_Steering_Engine;			//右舵机PWM

#define 	Pwm_3		Pwm_Left_Steering_Engine
#define 	Pwm_4		Pwm_Right_Steering_Engine

//************************************************************************************************
//*******关键赋值变量*****************************************************************************
extern uint8_t PID_Flag_Speed_Ring;					//PID速度环工作标识位（0为失能，1为使能）
extern uint8_t PID_Flag_Angle_Ring;					//PID角度环工作标识位（0为失能，1为使能）

extern uint8_t Debug_Flag;							//是否调试标识位（0为不调试，1为调试）

extern uint8_t In_Order_or_Reverse_Order_Flag;		//关于B区是否顺序还是逆序的标识位（0为顺序+，1为逆序-）

extern int16_t Left_Speed;							//左轮速度
extern int16_t Right_Speed;							//右轮速度

#define 	IOOROF		In_Order_or_Reverse_Order_Flag
#define 	PID_Flag	PID_Flag_Speed_Ring

#define 	Speed_1		Left_Speed
#define 	Speed_2		Right_Speed

//************************************************************************************************
//*******各个区域相关变量*************************************************************************
//———————准备区域

//———————区域A
extern int16_t A_Target_Runing_Speed; 				//A区目标行驶速度
extern uint8_t A_Work_Count;						//A区数量
extern uint8_t A_Spray_Head_State;					//A区喷头状态（用于表示喷洒工作是否完成）
extern uint8_t A_Voice_State;						//A区语音状态（用于表示语音播报工作是否完成）


//———————区域B
extern int16_t B_Target_Runing_Speed; 				//B区目标行驶速度
extern uint8_t B_Work_Count;						//B区数量
extern uint8_t B_Spray_Head_State;					//B区喷头状态（用于表示喷洒工作是否完成）
extern uint8_t B_Voice_State;						//B区语音状态（用于表示语音播报工作是否完成）

//———————区域C
extern int16_t C_Target_Runing_Speed; 				//C区目标行驶速度
extern uint8_t C_Work_Count;						//C区数量
extern uint8_t C_Spray_Head_State;					//C区喷头状态（用于表示喷洒工作是否完成）
extern uint8_t C_Voice_State;						//C区语音状态（用于表示语音播报工作是否完成）

extern uint8_t C_Servo_State;						//1左 2右



extern int8_t 	Count1;								//数量
extern int8_t 	Count2;								//数量
//———————区域D
extern int16_t D_Target_Runing_Speed; 				//D区目标行驶速度
extern uint8_t D_Work_Count;						//D区数量
extern uint8_t D_Spray_Head_State;					//D区喷头状态（用于表示喷洒工作是否完成）
extern uint8_t D_Voice_State;						//D区语音状态（用于表示语音播报工作是否完成）


//———————停止区域
//************************************************************************************************
//**重定义****************************************************************************************
//**观点管IO口重定义******************************************************************************
#define		F13 	GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_13)		//上层左光电管IO口
#define		F15 	GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_15)		//上层右光电管IO口

#define		F12 	GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_12)		//下层左光电管IO口
#define		F14 	GPIO_ReadInputDataBit(GPIOF, GPIO_Pin_14)		//下层右光电管IO口

//#define		D14 	GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_14)		//喷头左光电管IO口
//#define		D15 	GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_15)		//喷头右光电管IO口

/* 测试模拟数据改成0, 测试开关量数据改成1 */
#define GW_READ_DIGITAL_DATA 1



#endif




