#ifndef __TURN_RIGHT_H__
#define __TURN_RIGHT_H__

void Turn_Right(void);
void Turn_Left(void);

#endif

