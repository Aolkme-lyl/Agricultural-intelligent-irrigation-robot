#ifndef __B_PROCESS_H__		
#define __B_PROCESS_H__		

#include "stdint.h"

extern uint8_t Flag_B;

void B_Process_Versions_1(void);		//B_Process

#define 	B_P_V_1()		B_Process_Versions_1()
#endif
