#include "stm32f10x.h"                  // Device header
#include "initializer.h"

uint8_t Flag_A;

void A_Process_Versions_1(void)			//A区阶段函数第一版
{
	//**先赋值***********************************************************************************
	Process = 1;						//阶段1
	Flag_A = 6;
	Count = 0;
	Area = 0;
	delay_s(2);
	delay_s(2);
	delay_s(2);
	printf("kkkkk\r\n");
	//**初始角度XYZ记录**************************************************************************
	Initial_X = X;
	Initial_Y = Y;
	Initial_Z = Z;
	//**语音播报*********************************************************************************
	Voice_Menu(6);			//语音播报
	delay_s(2);
	//**舵机角度设置*****************************************************************************
	Servo_Angle_Adjust(0);
	
	delay_ms(1000);
	//printf("X:%d,Y:%d,Z:%d",Initial_X,Initial_Y,Initial_Z);
	//**前进*************************************************************************************
	T_S_F7;
	delay_ms(1000);
	while(Process == 1 && Flag_A > 0)
	{
		//printf("AA\r\n");
		EXTI_DRPS_A_Versions_1();
		if (Flag_A == 0)
		{
			T_S_F0;
		}
	}
	
		
}


