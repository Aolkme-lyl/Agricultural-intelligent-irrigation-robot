#include "stm32f10x.h"                  		// Device header
#include "initializer.h"

void Start_Process_Versions_1(void)				//开始阶段函数第一版
{
//	Servo_Angle_Set(0,0);						//先把舵机竖起来
	
	
	
	Process = 0;								//阶段0等待区域
	//***第一行显示（CAA  IRR）:中国自动化学会——智能灌溉项目****************************************
	OLED_ShowString(1,1,"CAA IRR");				//第一行显示；
	
	Servo_Angle_Adjust(0);
	
	//**获取旱情信息********************************************************************************
	//mT_R_Lora();									//获取旱情；
	
	//**获取到旱情后进行显示************************************************************************	
	int8_t i,j;
	for (i = 0; i <= 2; i++)
	{
		for (j = 0; j <= 5; j++)
		{
			OLED_ShowNum (i+2,j+1,Situat[i][j],1);
		}
	}	
	//**进行语音播报********************************************************************************
	delay_s(2);
	Voice_Menu(4);					//语音播报
	delay_s(5);
	//**********************************************************************************************
}

void End_Process_Versions_1(void)				//结束阶段函数第一版
{
	uint8_t Phase = 0;
	
	Process = 7;
	
	Servo_Angle_Adjust(0);
	
	//Motor_Backwards();
	T_S_F7;
	while (Process == 7)
	{
		if (Phase == 0 && (Grayscale_Sensor_ReadInput() >= 2))
		{
			delay_ms(1000);
			delay_ms(1000);
			delay_ms(600);
			T_S_F0;
			Voice_Menu(5);
			Process = 0;
			while(1);
		}
	}
}
