#include "stm32f10x.h"                  // Device header
#include "initializer.h"
#include "C_Process.h"



uint8_t Flag_C = 6;

//uint16_t timess = 200;
//uint16_t i;
//uint16_t j;

//void C_delay_L(void)
//{
//	i = timess / 10;
//	while (i > 0)
//	{
//		delay_ms(10);
//		if(F15 == 0)
//		{
//			j = i;
//			i = 0;
//		}else{
//			i--;
//		}
//	}
//}

//void C_delay_R(void)
//{
//	i = timess / 10;
//	while (i > 0)
//	{
//		delay_ms(10);
//		if(F13 == 0)
//		{
//			j = i;
//			i = 0;
//		}else{
//			i--;
//		}
//	}
//}




void C_Process_Versions_1(void)			//B_Process
{
	Process = 3;				//A区
	Flag_C = 6;
	
	Count = 0;
	
	Count1 = 0;
	Count2 = 0;
	
	Area = 2;
	Voice_Menu(8);			//语音播报
	delay_ms(1000);
	delay_ms(1000);
	
	Servo_Angle_Adjust(0);
	delay_ms(1000);
	Adjust_Direction_Turn_Function();
	delay_ms(1000);
	T_S_FC;
	delay_ms(1000);

	//Timer_Init2();
	
	while(Process == 3 && Flag_C > 0)	
	{
		EXTI_DRPS_C_Versions_1();
		//EXTI_DRPS_C_Versions_2();
		if (Flag_C == 0)
		{
			Process = 5;
			T_S_F0;
		}
		
	}
	
	
}	

	


