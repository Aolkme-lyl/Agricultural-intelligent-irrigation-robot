#include "stm32f10x.h"  
#include "initializer.h"
#include "Debugs.h"

void Debugging_Program_1(void)
{
//	Servo_PWM_Set1(1000);
//	Servo_PWM_Set2(1120);
//	
	
//	Servo_Angle_Set(0, 0);
	
	OLED_ShowString(1,1,"CAA IRR");
	Process = 4;
	Servo_Angle_Adjust(0);
//	Servo_Angle_Set(90, 110);
//	T_S_F3;
//	Start_Process_Versions_1();
	
//	A_P_V_1();
//	B_P_V_1();
//	printf("11\r\n");
//	moveServos(2, 3000, 1,1595,2,1520); //800毫秒2号舵机到1200位置，9号舵机到2300位置
//	T_S_F3;
	delay_s(3);
	delay_s(3);
	Initial_X = X;
	Initial_Y = Y;
	Initial_Z = Z;
//	C_P_V_1();
///	T_R_P();
//	D_P_V_1();
	L_O(1);
	R_O(1);
	
	OLED_ShowString(2,1,"CAA IRR");
//	delay_s(3);
//	delay_s(3);
//	T_R_P();
//	Process = 2;
//	Adjust_Direction_Turn_Function();
	while(1){
//		Adjust_Direction_Turn_Function();
		//Servo_Angle_Adjust(0);
//		delay_ms(3);
	//	moveServos(2, 3000, 1,1700,2,1640);
////		Adjust_Direction_Turn();
//		printf("%d|%d|%d\r\n",X,Y,Z);
//		Servo_Angle_Adjust(1);
//		delay_ms(1000);
//		delay_s(3);
		delay_s(3);
		
//		moveServo(1, 1500, 1000); //1秒移动1号舵机至2000位置
	//	delay_ms(3000);
//		Servo_Angle_Adjust(1);
//		moveServo(1, 2000, 1000); //1秒移动1号舵机至2000位置
//		moveServos(2, 3000, 1,1595,2,1520);
//		moveServo(1, 1000, 1000); //1秒移动1号舵机至2000位置
	//	delay_ms(3000);
		
//		Servo_PWM_Set1(500);
//		Servo_PWM_Set2(500);
//		delay_ms(1000);
//		delay_ms(1000);
//		delay_ms(1000);
//		
//		
//		Servo_PWM_Set1(1500);
//		Servo_PWM_Set2(1500);
//		delay_ms(1000);
//		delay_ms(1000);
//		delay_ms(1000);
//		L_O(1); R_O(1);	
//		Voice_Menu(12);
//		delay_ms(1000);
//		delay_ms(1000);
//		Voice_Menu(4);
//		Servo_PWM_Set1(2499);
//		Servo_PWM_Set2(2499);
//		delay_ms(1000);
//		delay_ms(1000);
//		delay_ms(1000);
//		delay_ms(1000);
//		L_O(0); R_O(0);	
//		printf("123123\r\n");
//		"X:%d, Y:%d, Z:%d\r\n", X, Y, Z);
//		delay_ms(500);
//		delay_ms(500);
		//printf("%d\r\n",Grayscale_Sensor_ReadInput());
	}

	



}


