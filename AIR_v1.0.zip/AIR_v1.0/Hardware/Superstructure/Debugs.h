#ifndef __DEBUGS_H__
#define __DEBUGS_H__


void Debugging_Program_1(void);






#endif




