#ifndef __A_PROCESSS_H__
#define	__A_PROCESSS_H__

#include "stdint.h"						// 定义固定名称

extern uint8_t Flag_A;

void A_Process_Versions_1(void);

#define 	A_P_V_1()		A_Process_Versions_1()


#endif
