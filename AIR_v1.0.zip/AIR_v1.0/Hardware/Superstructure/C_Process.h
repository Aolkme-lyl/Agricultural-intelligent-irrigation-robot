#ifndef __C_PROCESS_H__		
#define __C_PROCESS_H__		

#include "stdint.h"

	
extern uint8_t Flag_C;


//extern uint16_t timess;
//extern uint16_t i;
//extern uint16_t j;

void C_delay_L(void);
void C_delay_R(void);
void C_Process_Versions_1(void);		//区域C

#define 	C_P_V_1()		C_Process_Versions_1()

#endif
