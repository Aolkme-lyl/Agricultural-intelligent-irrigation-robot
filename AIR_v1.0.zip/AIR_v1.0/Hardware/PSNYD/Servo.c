#include "stm32f10x.h"                  // Device header
#include "initializer.h"
#include "PWM.h" 
#include "delay.h"
#include "Servo.h"


int16_t Angle_Difference_X;		//角度差
uint8_t Position_X;				//1：右；2：左



void Servo_Angle(uint16_t Lpwm, uint16_t Rpwm)				// 舵机设置PWM
{
	Servo_PWM_Set3(Lpwm);
	Servo_PWM_Set4(Rpwm);
}


void Servo_Angle_Set(uint16_t L_Angle, uint16_t R_Angle)
{
	uint16_t LPWM = 0;
	uint16_t RPWM = 0;
	
	if(L_Angle < 90){
		LPWM = 1150 + (uint16_t)((L_Angle * 7.2));
	}else if(L_Angle >= 90){
		LPWM = 1800 + (uint16_t)(((L_Angle - 90) * 7.2));
	}
	
	if(R_Angle < 90){
		RPWM = 1750 - (R_Angle * 7);
	}else if(R_Angle >= 90){
		RPWM = 1150 - ((R_Angle - 90) * 7);
	}
	
	//printf("%d,%d\r\n",LPWM,RPWM);
	
	Servo_PWM_Set3(LPWM);
	Servo_PWM_Set4(RPWM);
}	

void Calculate_Angle_Position_X(int16_t InitialAngle_X, int16_t SecondAngle_X)
{
	Angle_Difference_X = SecondAngle_X - InitialAngle_X;
	
	// 将夹角限制在-180度到+180度之间
    if (Angle_Difference_X > 1800) {
        Angle_Difference_X -= 3600;
    } else if (Angle_Difference_X < -1800) {
        Angle_Difference_X += 3600;
    }
	//判断当前方向是在初始方向的左边还是右边
	if (Angle_Difference_X == 0){		
		Position_X = 0;			// 同一角度	
	} else if (Angle_Difference_X < 0){
		Position_X = 1;			// 往左倾斜
	} else if (Angle_Difference_X > 0){
		Position_X = 2;			// 往右倾斜
	}
}

void Servo_PWM_Put_Calculation(uint8_t unfinished_or_finished)
{
	if (unfinished_or_finished == 0)
	{
		if (Angle_Difference_X < -20)
		{
			Left_Angle =100 - ((- Angle_Difference_X ) / 10);
			Right_Angle = 110 + ((- Angle_Difference_X ) / 10);
		}
		else if (Angle_Difference_X > 20)
		{		
			Left_Angle =100 + (Angle_Difference_X  / 10);
			Right_Angle = 110 - (Angle_Difference_X  / 10);
		}
		Left_Angle_Last = Left_Angle;
		Right_Angle_Last = Right_Angle;
	}
	else if(unfinished_or_finished == 1)
	{
		if (Angle_Difference_X < -20)
		{
			Left_Angle = 120 - ((- Angle_Difference_X ) / 10);
			Right_Angle = 142 + ((- Angle_Difference_X ) / 10);
		}
		else if (Angle_Difference_X > 20) 
		{		
			Left_Angle = 120 + (Angle_Difference_X  / 10);
			Right_Angle = 142 - ( Angle_Difference_X  / 10);
		}		
	}
}





void Servo_Angle_Adjust(uint8_t unfinished_or_finished)			// A、B、C、D区舵机调整
{
	if (unfinished_or_finished == 0){
		switch (Process){
			case 0 : Servo_Angle_Set(20, 20); 	delay_ms(1000);moveServos(2, 1000, 1,1425,2,1580); delay_ms(3000);			break;
			case 1 : Servo_Angle_Set(100, 100); delay_ms(1000);moveServos(2, 1000, 1,1425,2,1580);	delay_ms(3000);			break;
			case 2 : Servo_Angle_Set(100, 100); delay_ms(1000);moveServos(2, 1000, 1,1425,2,1580);	delay_ms(3000);			break;
			case 3 : Left_Angle = 100; Right_Angle = 110;
				Calculate_Angle_Position_X(Initial_X, X);Servo_PWM_Put_Calculation(0);
				Servo_Angle_Set(Left_Angle, Right_Angle);delay_ms(1000);
				moveServos(2, 1000, 1,1425,2,1580);	delay_ms(3000);			break;
			case 4 : Servo_Angle_Set(125, 140); delay_ms(1000);moveServos(2, 1000, 1,1230,2,1420);	delay_ms(3000);			break;
			case 5 : Servo_Angle_Set(20, 20); 	delay_ms(1000);moveServos(2, 1000, 1,1425,2,1580);	delay_ms(3000);			break;
			case 6 : Servo_Angle_Set(20, 20); 	delay_ms(1000);moveServos(2, 1000, 1,1425,2,1580);	delay_ms(3000);			break;
			case 7 : Servo_Angle_Set(20, 20); 	delay_ms(1000);moveServos(2, 1000, 1,1425,2,1580);	delay_ms(3000);			break;
		}
	}else if (unfinished_or_finished == 1){
		switch (Process){
			case 0 : Servo_Angle_Set(20, 20); 	delay_ms(1000);moveServos(2, 1000, 1,1425,2,1580);	delay_ms(3000);			break;
			case 1 : Servo_Angle_Set(130, 140); delay_ms(1000);moveServos(2, 1000, 1,1345,2,1520);	delay_ms(3000);			break;
			case 2 : Servo_Angle_Set(115, 120); delay_ms(1000);moveServos(2, 1000, 1,1345,2,1520);	delay_ms(3000);			break;
			case 3 :	
				Left_Angle = 120; Right_Angle = 142;
				Calculate_Angle_Position_X(Initial_X, X);Servo_PWM_Put_Calculation(1);
				if (C_Servo_State == 1)
				{
					Servo_Angle_Set(Left_Angle, Right_Angle_Last);
					delay_ms(1000);moveServos(2, 1000, 1,1345,2,1580);	delay_ms(3000);	
				}
				else if (C_Servo_State == 2)
				{
					Servo_Angle_Set(Left_Angle_Last, Right_Angle);
					delay_ms(1000);moveServos(2, 1000, 1,1425,2,1520);	delay_ms(3000);
				}
////				Left_Angle = 120; Right_Angle = 130;
////				Calculate_Angle_Position_X(Initial_X, X);Servo_PWM_Put_Calculation(1);
////				Servo_Angle_Set(Left_Angle, Right_Angle); delay_ms(1000);moveServos(2, 1000, 1,1595,2,1520);	delay_ms(3000);
				break;
			case 4 : Servo_Angle_Set(120, 130); delay_ms(1000);moveServos(2, 1000, 1,1345,2,1520);	delay_ms(3000);			break;
			case 5 : Servo_Angle_Set(20, 20); 	delay_ms(1000);moveServos(2, 1000, 1,1425,2,1580);	delay_ms(3000);			break;
			case 6 : Servo_Angle_Set(20, 20); 	delay_ms(1000);moveServos(2, 1000, 1,1425,2,1580);	delay_ms(3000);			break;
			case 7 : Servo_Angle_Set(20, 20); 	delay_ms(1000);moveServos(2, 1000, 1,1425,2,1580);	delay_ms(3000);			break;
		}
	}
}



void Servo_Angle_Auto_Adjust(void)
{
	





}	



