#ifndef __USART3_H__
#define __USART3_H__
#include "initializer.h"
#include "stdint.h"
#include <stdio.h>
#include <stdint.h>
//extern char Serial3_RxPacket[];
//extern uint8_t Serial3_RxFlag;


extern u8 USART_RX_BUF[64];     //接收缓冲,最大63个字节.末字节为换行符 
extern u8 USART_RX_STA;         //接收状态标记	



void Serial3_Init(void);

void uartWriteBuf(uint8_t *buf, uint8_t len);




//void Speed_extractNumbers(const char* str, int* num1, int* num2);

#endif
