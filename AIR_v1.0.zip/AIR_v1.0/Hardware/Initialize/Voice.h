#ifndef __Voice_H__
#define __Voice_H__
 
#include "sys.h"

#define A1 PDout(0)// 
#define A2 PDout(1)// 
#define A3 PDout(3)// 
#define A4 PDout(7)// 

void Voice_Delay(void);

void Voice_Init(void);
void Voice_Menu(u8 a);
		 				    
#endif

