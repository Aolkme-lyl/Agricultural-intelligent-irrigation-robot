#ifndef __GRAYSCALE_SENSOR_H__		
#define __GRAYSCALE_SENSOR_H__		

#include "stdint.h"

//八路灰度循迹IO口状态
extern uint8_t IO1;
extern uint8_t IO2;
extern uint8_t IO3;
extern uint8_t IO4;
extern uint8_t IO5;
extern uint8_t IO6;
extern uint8_t IO7;
extern uint8_t IO8;
extern uint8_t IO9;
extern uint8_t IO10;
extern uint8_t IO11;
extern uint8_t IO12;
extern uint8_t IO13;
extern uint8_t IO14;
extern uint8_t IO15;
extern uint8_t IO16;

// 定义变量来存储连续为1的IO变量的起始位置和结束位置
extern int startIdx;
extern int endIdx;
	




void Grayscale_Sensor_Init_1(void);		//八路灰度传感器IO口输入初始化
void Grayscale_Sensor_Init_2(void);	
int Grayscale_Sensor_ReadInput(void);			//IO口状态读取
int Grayscale_Sensor_ReadInput_4(void);			//IO口状态读取
int Grayscale_Sensor_ReadInput_Analyse(void);	
#endif


