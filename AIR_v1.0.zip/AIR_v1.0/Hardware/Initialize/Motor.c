#include "stm32f10x.h"                  // Device header
#include "initializer.h"


void Motor_Init(void)					//开启IO口控制口
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_3 | GPIO_Pin_4;		//PF0 PF1 PF2 PF3
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOF, &GPIO_InitStructure);
	
}

//***************************************************************
void L_F_M(uint8_t A, uint8_t B)			//左前轮
{
	if (A == 0){
		GPIO_ResetBits(GPIOF,GPIO_Pin_0);
	}
	if (A == 1){		
		GPIO_SetBits(GPIOF,GPIO_Pin_0);
	}
	if (B == 0){
		GPIO_ResetBits(GPIOF,GPIO_Pin_1);
	}
	if (B == 1){
		GPIO_SetBits(GPIOF,GPIO_Pin_1);
	}
}

void R_F_M(uint8_t A, uint8_t B)			//右前轮
{
	if (A == 0){
		GPIO_ResetBits(GPIOF,GPIO_Pin_3);
	}
	if (A == 1){		
		GPIO_SetBits(GPIOF,GPIO_Pin_3);
	}
	if (B == 0){
		GPIO_ResetBits(GPIOF,GPIO_Pin_4);
	}
	if (B == 1){
		GPIO_SetBits(GPIOF,GPIO_Pin_4);
	}
}


//***************************************************************
//****************************************
//	void Motor_PWM_Set1(uint16_t Compare);
//	void Motor_PWM_Set2(uint16_t Compare);

//
//	void L_F_M(uint8_t A, uint8_t B);
//	void R_F_M(uint8_t A, uint8_t B);

//****************************************
void Motor_Forward(void)	//前进
{
	L_F_M(1, 0);
	R_F_M(0, 1);
}

void Motor_Backwards(void) //后退
{
	L_F_M(0, 1);
	R_F_M(1, 0);
}


void Motor_Stop(void)		//制动停止
{
	L_F_M(1, 1);
	R_F_M(1, 1);
}

void Motor_Disable(void)	//断电停止
{
	L_F_M(0, 0);
	R_F_M(0, 0);
}


void Motor_Left(void)	//左转
{
	L_F_M(0, 1);
	R_F_M(0, 1);

}



void Motor_Right(void)	//右转
{
	L_F_M(1, 0);
	R_F_M(1, 0);

}


