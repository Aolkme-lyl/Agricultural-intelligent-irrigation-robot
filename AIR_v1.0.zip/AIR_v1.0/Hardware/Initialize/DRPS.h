#ifndef __DRPS_H__		//Diffuse-reflective photoelectric sensors
#define __DRPS_H__		//漫反射式光电传感器

void Drps_Init_Open(void);
void Drps_Init_Open2(void);
void Drps_Init_Open3(void);
void Drps_Init_Close(void);

void EXTI_DRPS_A_Versions_1(void);
void EXTI_DRPS_B_Versions_1(void);
void EXTI_DRPS_C_Versions_1(void);
//void EXTI_DRPS_C_Versions_2(void);
void EXTI_DRPS_D_Versions_1(void);
//void EXTI_DRPS_D_Versions_2(void);
void EXTI_DRPS_D_Versions_3(void);
//void EXTI15_10_IRQHandler(void);

#endif

