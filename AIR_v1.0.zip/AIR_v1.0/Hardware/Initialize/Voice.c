#include "Voice.h"
#include "stm32f10x.h"                  // Device header
#include "initializer.h"
#include "delay.h"
#include "sys.h"
void Voice_Init(void)
{
 
	GPIO_InitTypeDef  GPIO_InitStructure;
 	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_3 | GPIO_Pin_7;		
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 
	GPIO_Init(GPIOD, &GPIO_InitStructure);					 
	A1 = 1; A2 = 1;A3 = 1; A4 = 1;
	
	
}

void Voice_Delay(void)
{
	delay_ms(150);
	A1 = 1;
	A2 = 1;
	A3 = 1;
	A4 = 1;
}
 
void Voice_Menu(u8 a)
{
	switch(a)

	{
		case 1 : A1 = 0; A2 = 1; A3 = 1; A4 = 1;				//轻微干旱
			Voice_Delay();
			break;
		
		case 2 : A1 = 1; A2 = 0; A3 = 1; A4 = 1;				//一般干旱
			Voice_Delay();
			break;
		
		case 3 : A1 = 0; A2 = 0; A3 = 1; A4 = 1;				//严重干旱
			Voice_Delay();
			break;
		
		case 4 : A1 = 1; A2 = 1; A3 = 0; A4 = 1;				//起始语
			Voice_Delay();
			break;
		
		case 5 : A1 = 0; A2 = 1; A3 = 0; A4 = 1;				//结束语
			Voice_Delay();
			break;
		
		case 6: A1 = 1; A2 = 0; A3 = 0; A4 = 1;					//进入A区
			Voice_Delay();
			break;
		
		case 7: A1 = 0; A2 = 0; A3 = 0; A4 = 1;					//进入B区
			Voice_Delay();
			break;
		
		case 8: A1 = 1; A2 = 1; A3 = 1; A4 = 0;					//进入C区
			Voice_Delay();
			break;
			
		case 9: A1 = 0; A2 = 1; A3 = 1; A4 = 0;					//进入D区
			Voice_Delay();
			break;
		
		case 10: A1 = 1; A2 = 0; A3 = 1; A4=0;					// 当前行驶方向左侧
			Voice_Delay();
			break;
			
		case 11: A1 = 0; A2 = 0; A3 = 1; A4=0;					// 当前行驶方向右侧
			Voice_Delay();
			break;
			
		case 12: A1 = 1; A2 = 1; A3 = 0; A4=0;					//注意哈
			Voice_Delay();
			break;
		
		case 13:A1=0;A2=1;A3=0;A4=0;delay_ms(200);A1=1;A2=1;A3=1;A4=1;break;//
		
		case 14:A1=1;A2=0;A3=0;A4=0;delay_ms(200);A1=1;A2=1;A3=1;A4=1;break;//
		
		case 15:A1=0;A2=0;A3=0;A4=0;delay_ms(200);A1=1;A2=1;A3=1;A4=1;break;//
		
		case 16:A1=0;A2=1;A3=0;A4=1;delay_ms(400);A1=1;A2=1;A3=1;A4=1;break;//


	}
//return;
}









