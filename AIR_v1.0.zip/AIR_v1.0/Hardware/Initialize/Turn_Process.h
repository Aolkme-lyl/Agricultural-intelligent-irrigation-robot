#ifndef __TURN_PROCESS_H__		
#define __TURN_PROCESS_H__		
#include "stdint.h"

void T_L_P(void);
void T_R_P(void);

void Adjust_Direction_Turn(void);				//
void Adjust_Direction_Turn_Function(void);		//

#endif


