#ifndef __PWM_H__
#define __PWM_H__

void Motor_PWM_Init(void);
void Servo_PWM_Init(void);

//void Motor_PWM_Set1(uint16_t Compare);
//void Motor_PWM_Set2(uint16_t Compare);
void Motor_PWM_Set3(uint16_t Compare);
void Motor_PWM_Set4(uint16_t Compare);


//void Servo_PWM_Set1(uint16_t Compare);
//void Servo_PWM_Set2(uint16_t Compare);
void Servo_PWM_Set3(uint16_t Compare);
void Servo_PWM_Set4(uint16_t Compare);

void Motor_PWM_stop(void);		//PWM输出0停止
void Motor_PWM(uint8_t pwm);	//设置PWM值控制车数
void Motor_ALL_PWM(uint8_t pwm1, uint8_t pwm2);	//设置PWM值控制车数	

void Motor_L_Set(int16_t Input_Pwm);
void Motor_R_Set(int16_t Input_Pwm);

#endif
