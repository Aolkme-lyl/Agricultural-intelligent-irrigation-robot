#include "stm32f10x.h"                  // Device header
#include "initializer.h"
#include "DRPS.h"
#define drps_upside(n) 


//**********************************************************************************
void Drps_Init_Open(void)			//上层光电管	F13 F15
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF,ENABLE);
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_15 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOF, &GPIO_InitStructure);
	
//****************				PF13				****************	
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOF,GPIO_PinSource13);
//	
//	EXTI_InitTypeDef EXTI_InitStruct;
//	EXTI_InitStruct.EXTI_Line = EXTI_Line13;
//	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
//	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
//	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
//	EXTI_Init(&EXTI_InitStruct);

////****************				PF15				****************		
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOF,GPIO_PinSource15);
//	
//	EXTI_InitStruct.EXTI_Line = EXTI_Line15;
//	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
//	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
//	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
//	EXTI_Init(&EXTI_InitStruct);
	
//**********		开启中断		**************
//	NVIC_InitTypeDef NVIC_InitStructure;
//	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//	NVIC_Init(&NVIC_InitStructure);
	
}
//**********************************************************************************

void Drps_Init_Open2(void)			//下层光电管	F12 F14
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF,ENABLE);
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_14 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOF, &GPIO_InitStructure);
	
//****************				PF12				****************	
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOF,GPIO_PinSource12);
//	
//	EXTI_InitTypeDef EXTI_InitStruct;
//	EXTI_InitStruct.EXTI_Line = EXTI_Line12;
//	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
//	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
//	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising;
//	EXTI_Init(&EXTI_InitStruct);

//****************				PF14				****************		
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOF,GPIO_PinSource14);
//	
//	EXTI_InitStruct.EXTI_Line = EXTI_Line14;
//	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
//	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
//	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
//	EXTI_Init(&EXTI_InitStruct);
	
//**********		开启中断		**************
//	NVIC_InitTypeDef NVIC_InitStructure;
//	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//	NVIC_Init(&NVIC_InitStructure);
	
}


//**********************************************************************************

void Drps_Init_Open3(void)			//喷头光电管	D14 D15
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14 | GPIO_Pin_15 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
}
//**********************************************************************************



void EXTI_DRPS_A_Versions_1(void)
{
	if(F13 == 0)
	{
		delay_ms(10);
		if(F13 == 0)				//消除光电管IO口电流的波动
		{							
			if (Flag_A > 0)			
			{
				T_S_F0;
//				if (Flag_A != 0)
//				{
//					Adjust_Direction_Turn();
//				}
				//D_Clear;
				Servo_Angle_Adjust(1);								//舵机姿态动作
				Voice_Menu(Situat[Area][Count]);					//语音播报
				delay_ms(500);
				
				Spray_A_and_B(Situat[Area][Count]);					//喷水
				delay_ms(500);										//%可删除项
				Servo_Angle_Adjust(0);
				delay_ms(500);
				T_S_F7;												//前进
				delay_ms(800);										//加延时防止再次扫到
				//**数值更新************
				Count ++;
				Flag_A --;
				//**********************
				if (Flag_A == 0)
				{
					//Adjust_Direction_Turn();
					Process = 6;
				}
				
			}
			
			else if(Count >= 6)
			{
				T_S_F0;								//停车！
			}
		}
	}
}

void EXTI_DRPS_B_Versions_1(void)
{	
	if(F13 == 0)							//看场地坡偏向 选择左右F13/F15
	{
		delay_ms(10);
		if(F13 == 0)						//经典消抖
		{
			if(Flag_B > 0)
			{
				Voice_Menu(Situat[Area][Count]);	//语音播报
				delay_ms(500);						//等一下再停
				T_S_F0;	
				delay_ms(500);
				Servo_Angle_Adjust(1);
				delay_ms(1000);
				Spray_A_and_B(Situat[Area][Count]);
				delay_ms(500);
				Servo_Angle_Adjust(0);
				delay_ms(1000);
				delay_ms(1000);
				T_S_F5;
				while(F12 == 0);			//看场地坡偏向 选择左右F12/F14
				//**数据更新*************************
				if(IOOROF == 0){
					Count ++;
				}else if(IOOROF == 1){
					Count --;
				}
				Flag_B --;
				//***********************************
				delay_ms(800);				//延时到进入下一个盆，以防误判
			}
		}
	}
}

void EXTI_DRPS_C_Versions_1(void)
{
	if(F13 == 0)											//左边识别到
	{
		T_S_F0;
		
		Voice_Menu(Situat[Area][Count]);					//语音播报
		delay_ms(500);
		C_Servo_State = 1;
		Servo_Angle_Adjust(1);
		delay_ms(1000);
		delay_ms(1000);
		Spray_C_and_D(Situat[Area][Count], 1);				//喷水
		Servo_Angle_Adjust(0);
		delay_ms(1000);
		delay_ms(1000);										//%可删除项
		T_S_FC;												//前进
		C_Spray_Head_State = 1;
		while((C_Spray_Head_State == 1) || (C_Spray_Head_State == 2))
		{		
			if(F15 == 0)
			{
				T_S_F0;
				Voice_Menu(Situat[Area][Count]);					//语音播报
				delay_ms(500);
				C_Servo_State = 2;
				Servo_Angle_Adjust(1);
				delay_ms(1000);
				delay_ms(1000);
				Spray_C_and_D(Situat[Area][Count], 2);				//喷水
				Servo_Angle_Adjust(0);
				delay_ms(1000);
				delay_ms(1000);										//%可删除项
				T_S_FC;									
				while(F12 == 0 || F14 == 0);
				C_Spray_Head_State = 0;
			}
			if (F12 == 1 && C_Spray_Head_State == 1)
			{
				C_Spray_Head_State = 2;
			}else if (F13 == 0 && C_Spray_Head_State == 2)
			{
				C_Spray_Head_State = 0;
			}
			
		}
		//**数值更新************
		Count ++;
		Flag_C --;
		//**********************
	}
	else if(F15 == 0)
	{
		T_S_F0;
		Voice_Menu(Situat[Area][Count]);					//语音播报
		delay_ms(500);
		C_Servo_State = 2;
		Servo_Angle_Adjust(1);
		delay_ms(1000);
		delay_ms(1000);
		Spray_C_and_D(Situat[Area][Count], 2);				//喷水
		Servo_Angle_Adjust(0);
		delay_ms(1000);
		delay_ms(1000);
												//%可删除项
		T_S_FC;												//前进
		C_Spray_Head_State = 1;
		while(C_Spray_Head_State == 1 || C_Spray_Head_State == 2)
		{
			if(F13 == 0)
			{
				T_S_F0;
				Voice_Menu(Situat[Area][Count]);					//语音播报
				delay_ms(500);
				C_Servo_State = 1;
				Servo_Angle_Adjust(1);
				delay_ms(1000);
				delay_ms(1000);
				Spray_C_and_D(Situat[Area][Count], 1);				//喷水
				Servo_Angle_Adjust(0);
				delay_ms(1000);
				delay_ms(1000);								//%可删除项
				T_S_FC;							
				while(F12 == 0 || F14 == 0);
				C_Spray_Head_State = 0;
			}
			if (F14 == 1 && C_Spray_Head_State == 1)
			{
				C_Spray_Head_State = 2;
			}else if (F15 == 0 && C_Spray_Head_State == 2)
			{
				C_Spray_Head_State = 0;
			}
			
		}
		//**数值更新************
		Count ++;
		Flag_C --;
		//**********************
	}
}


//void EXTI_DRPS_C_Versions_2(void)
//{
//	if(F13 == 0)											//左边识别到
//	{
//		C_delay_L();
//		if (j > 0)
//		{
//			delay_ms(j * 10);
//		}
//		T_S_F0;		
//		Voice_Menu(Situat[Area][Count]);					//语音播报
//		delay_ms(500);
//		C_Servo_State = 1;
//		Servo_Angle_Adjust(1);
//		delay_ms(1000);
//		delay_ms(1000);
//		Spray_C_and_D(Situat[Area][Count], 1);				//喷水
//		Servo_Angle_Adjust(0);
//		delay_ms(1000);
//		delay_ms(1000);										//%可删除项
//		T_S_F3;												//前进
//		C_Spray_Head_State = 1;
//		while(C_Spray_Head_State == 1)
//		{
//			if (j > 0){
//				delay_ms(200 - (j * 10));
//				j = 0;
//				T_S_F0;
//				Voice_Menu(Situat[Area][Count]);					//语音播报
//				delay_ms(500);
//				Servo_Angle_Adjust(1);
//				C_Servo_State = 2;
//				delay_ms(1000);
//				delay_ms(1000);
//				Spray_C_and_D(Situat[Area][Count], 2);				//喷水
//				Servo_Angle_Adjust(0);
//				delay_ms(1000);
//				delay_ms(1000);										//%可删除项
//				T_S_F3;									
//				while(F12 == 0 || F14 == 0);
//				C_Spray_Head_State = 0;
//			}
//			
//			if(F15 == 0 && C_Spray_Head_State == 1)
//			{
//				delay_ms(timess);
//				T_S_F0;
//				Voice_Menu(Situat[Area][Count]);					//语音播报
//				delay_ms(500);
//				Servo_Angle_Adjust(1);
//				C_Servo_State = 2;
//				delay_ms(1000);
//				delay_ms(1000);
//				Spray_C_and_D(Situat[Area][Count], 2);				//喷水
//				Servo_Angle_Adjust(0);
//				delay_ms(1000);
//				delay_ms(1000);										//%可删除项
//				T_S_F3;									
//				while(F12 == 0 || F14 == 0);
//				C_Spray_Head_State = 0;
//			}
//			if (F12 == 1 && C_Spray_Head_State == 1)
//			{
//				C_Spray_Head_State = 2;
//			}else if (F13 == 0 && C_Spray_Head_State == 2)
//			{
//				C_Spray_Head_State = 0;
//			}			
//		}
//		//**数值更新************
//		Count ++;
//		Flag_C --;
//		//**********************
//	}
//	else if(F15 == 0)
//	{
//		C_delay_R();
//		if (j > 0)
//		{
//			delay_ms(j * 10);
//		}
//		T_S_F0;
//		Voice_Menu(Situat[Area][Count]);					//语音播报
//		delay_ms(500);
//		C_Servo_State = 2;
//		Servo_Angle_Adjust(1);
//		delay_ms(1000);
//		delay_ms(1000);
//		Spray_C_and_D(Situat[Area][Count], 2);				//喷水
//		Servo_Angle_Adjust(0);
//		delay_ms(1000);
//		delay_ms(1000);
//												//%可删除项
//		T_S_F3;												//前进
//		C_Spray_Head_State = 1;
//		while(C_Spray_Head_State == 1)
//		{
//			if (j > 0){
//				delay_ms(200 - (j * 10));
//				j = 0;
//				T_S_F0;
//				Voice_Menu(Situat[Area][Count]);					//语音播报
//				delay_ms(500);
//				C_Servo_State = 1;
//				Servo_Angle_Adjust(1);
//				delay_ms(1000);
//				delay_ms(1000);
//				Spray_C_and_D(Situat[Area][Count], 1);				//喷水
//				Servo_Angle_Adjust(0);
//				delay_ms(1000);
//				delay_ms(1000);								//%可删除项
//				T_S_F3;							
//				while(F12 == 0 || F14 == 0);
//				C_Spray_Head_State = 0;
//			}
//			if(F13 == 0 && C_Spray_Head_State == 1)
//			{
//				delay_ms(timess);
//				T_S_F0;
//				Voice_Menu(Situat[Area][Count]);					//语音播报
//				delay_ms(500);
//				C_Servo_State = 1;
//				Servo_Angle_Adjust(1);
//				delay_ms(1000);
//				delay_ms(1000);
//				Spray_C_and_D(Situat[Area][Count], 1);				//喷水
//				Servo_Angle_Adjust(0);
//				delay_ms(1000);
//				delay_ms(1000);								//%可删除项
//				T_S_F3;							
//				while(F12 == 0 || F14 == 0);
//				C_Spray_Head_State = 0;
//			}
//			if (F14 == 1 && C_Spray_Head_State == 1)
//			{
//				C_Spray_Head_State = 2;
//			}else if (F15 == 0 && C_Spray_Head_State == 2)
//			{
//				C_Spray_Head_State = 0;
//			}
//			
//		}
//		//**数值更新************
//		Count ++;
//		Flag_C --;
//		//**********************
//	}
//}





void EXTI_DRPS_D_Versions_1(void)
{
	if(F12 == 0 && F14 == 0)								//左和右边识别到
	{
		delay_ms(1000);										//延时后
		T_S_F0;												//停车
		Voice_Menu(10);										//当前行驶方向左侧
		delay_ms(500);
		Voice_Menu(Situat_Dd[Count]);						//语音播报旱情
		delay_ms(500);
		Spray_C_and_D(Situat_Dd[Count], 1);					//喷水
		delay_ms(500);										//%可删除项
		Count ++;
		Flag_C --;
		Voice_Menu(11);									//当前行驶方向右侧
		delay_ms(500);
		Voice_Menu(Situat_Dd[Count]);					//语音播报旱情
		delay_ms(500);
		Spray_C_and_D(Situat[Area][Count], 2);				//喷水
		T_S_F3;												//前进
		while(F12 == 0 || F14 == 0);
		//**数值更新************
		Count ++;
		Flag_C --;
		//**********************
	}
}
/*
void EXTI_DRPS_D_Versions_2(void)
{
	u16 i1 = 100;
	u16 j1 = 0;
	
	if(F12 == 0)								//左和右边识别到
	{
		while (i1 > 0)
		{
			delay_ms(10);
			if (F14 == 0)
			{
				j1 = i1; 
				i1 = 0;
				 
			}
			i1--;
		}
		if (j1 > 0)
		{
			delay_ms(j1 * 10);
		}
		else
		{
			D_Spray_Head_State = 1;	
		}													//延时后
		T_S_F0;												//停车
		Voice_Menu(10);										//当前行驶方向左侧
		delay_ms(1000);
		delay_ms(1000);
		Voice_Menu(Situat_Dd[Count]);						//语音播报旱情
		delay_ms(1000);
		delay_ms(1000);
		Spray_C_and_D(Situat_Dd[Count], 1);					//喷水
		delay_ms(1000);										//%可删除项
		Count ++;
		Flag_C --;
		T_S_F3;
		if (j1 >0)
		{
			delay_ms(1000 - (j1 * 10));
			j1 = 0;
			T_S_F0;
			Voice_Menu(11);									//当前行驶方向右侧
			delay_ms(1000);
			delay_ms(1000);
			Voice_Menu(Situat_Dd[Count]);					//语音播报旱情
			delay_ms(1000);
			delay_ms(1000);
			Spray_C_and_D(Situat_Dd[Count], 2);				//喷水
			delay_ms(1000);
			T_S_F3;												//前进
			while(F12 == 0 || F14 == 0);						
		}
		else
		{
			while(D_Spray_Head_State == 1)
			{
				if (F14 == 0)
				{
					delay_ms(1000);	
					T_S_F0;
					Voice_Menu(11);									//当前行驶方向右侧
					delay_ms(1000);
					delay_ms(1000);
					Voice_Menu(Situat_Dd[Count]);					//语音播报旱情
					delay_ms(1000);
					delay_ms(1000);
					Spray_C_and_D(Situat_Dd[Count], 2);				//喷水
					delay_ms(1000);
					T_S_F3;												//前进
					while(F12 == 0 || F14 == 0);	
					D_Spray_Head_State = 0;
				}
			}
		}
		*数值更新************
		Count ++;
		Flag_C --;
		*********************	
	}	
	else if(F14 == 0)								//左和右边识别到
	{
		while (i1 > 0)
		{
			delay_ms(10);
			if (F14 == 0)
			{
				j1 = i1; 
				i1 = 0;
				 
			}
			i1--;
		}
		if (j1 > 0)
		{
			delay_ms(j1 * 10);
		}
		else
		{
			D_Spray_Head_State = 1;	
		}													//延时后
		T_S_F0;												//停车
		Voice_Menu(11);										//当前行驶方向左侧
		delay_ms(1000);
		delay_ms(1000);
		Voice_Menu(Situat_Dd[Count + 1]);						//语音播报旱情
		delay_ms(1000);
		delay_ms(1000);
		Spray_C_and_D(Situat_Dd[Count + 1], 2);					//喷水
		delay_ms(500);										//%可删除项
		Count ++;
		Flag_C --;
		T_S_F3;
		if (j1 >0)
		{
			delay_ms(1000 - (j1 * 10));
			j1 = 0;
			T_S_F0;
			Voice_Menu(10);									//当前行驶方向右侧
			delay_ms(1000);
			delay_ms(1000);
			Voice_Menu(Situat_Dd[Count - 1]);					//语音播报旱情
			delay_ms(1000);
			delay_ms(1000);
			Spray_C_and_D(Situat_Dd[Count - 1], 1);				//喷水
			T_S_F3;												//前进
			while(F12 == 0 || F14 == 0);						
		}
		else
		{
			while(D_Spray_Head_State == 1)
			{
				if (F14 == 0){
					delay_ms(1000);	
					T_S_F0;
					Voice_Menu(10);									//当前行驶方向右侧
					delay_ms(1000);
					delay_ms(1000);
					Voice_Menu(Situat_Dd[Count]);					//语音播报旱情
					delay_ms(1000);
					delay_ms(1000);
					Spray_C_and_D(Situat_Dd[Count - 1], 1);				//喷水
					delay_ms(1000);
					T_S_F3;												//前进
					while(F12 == 0 || F14 == 0);
					D_Spray_Head_State = 0;
				}
			}
		}
		**数值更新************
		Count ++;
		Flag_C --;
		**********************	
	}	
	
}*/
///########################################################################


void EXTI_DRPS_D_Versions_3(void)
{
	if(F12 == 0)
	{
		delay_ms(1000);
		T_S_F0;
		Voice_Menu(10);									//当前行驶方向右侧
		delay_ms(1000);
		delay_ms(1000);
		Voice_Menu(Situat_Dd[Count]);					//语音播报旱情
		delay_ms(1000);
		delay_ms(1000);
		Spray_C_and_D(Situat_Dd[Count], 1);				//喷水
		delay_ms(1000);
		T_S_F3;												//前进
		Count ++;
		Flag_D --;
		D_Spray_Head_State = 1;
		while(D_Spray_Head_State == 1)
		{
			if (F14 == 0)
			{
				delay_ms(1000);
				T_S_F0;
				Voice_Menu(11);									//当前行驶方向右侧
				delay_ms(1000);
				delay_ms(1000);
				Voice_Menu(Situat_Dd[Count]);					//语音播报旱情
				delay_ms(1000);
				delay_ms(1000);
				Spray_C_and_D(Situat_Dd[Count], 2);				//喷水
				delay_ms(1000);
				T_S_F3;
				while(F12 == 0 || F14 == 0);
				Count ++;
				Flag_D --;
				D_Spray_Head_State = 0;
			}
		}
	}
	else if(F14 == 0)
	{
		delay_ms(1000);
		T_S_F0;
		Voice_Menu(11);									//当前行驶方向右侧
		delay_ms(1000);
		delay_ms(1000);
		Voice_Menu(Situat_Dd[Count + 1]);					//语音播报旱情
		delay_ms(1000);
		delay_ms(1000);
		Spray_C_and_D(Situat_Dd[Count + 1], 2);				//喷水
		delay_ms(1000);
		T_S_F3;												//前进
		Flag_D --;
		D_Spray_Head_State = 1;
		while(D_Spray_Head_State == 1)
			if (F12 == 0)
			{
				delay_ms(1000);
				T_S_F0;
				Voice_Menu(10);									//当前行驶方向右侧
				delay_ms(1000);
				delay_ms(1000);
				Voice_Menu(Situat_Dd[Count]);					//语音播报旱情
				delay_ms(1000);
				delay_ms(1000);
				Spray_C_and_D(Situat_Dd[Count], 1);				//喷水
				delay_ms(1000);
				T_S_F3;
				while(F12 == 0 || F14 == 0);
				Count ++;
				Count ++;
				Flag_D --;
				D_Spray_Head_State = 0;
		}
	}
	
	
}





//**********************************************************************************

