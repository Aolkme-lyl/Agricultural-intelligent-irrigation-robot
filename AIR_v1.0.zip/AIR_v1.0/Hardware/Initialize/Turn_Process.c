#include "Turn_Process.h" 
#include "stm32f10x.h"  
#include "initializer.h"
#include "PWM.h"
#include "Motor.h"
#include "delay.h"
#include "Grayscale_Sensor.h"
#include "usart2.h"
#include "imu901.h"
#include "PID.h"
#include "Serial.h"
#include "Voice.h"

uint8_t PWMPWM;

void T_L_P(void)
{
	Count = 0;
	
	Process = 5;			//左转过程标志

	uint8_t Phase = 1;
	
	T_S_F7;
	
	while(Phase)
	{
		while(Phase == 1 || Phase == 3)
		{
			if ((Grayscale_Sensor_ReadInput() + Grayscale_Sensor_ReadInput_4()) >= 4 )
			{
				delay_ms(10);
				if ((Grayscale_Sensor_ReadInput() + Grayscale_Sensor_ReadInput_4()) >= 4 )
				{
					if (Phase == 1)
					{
						delay_ms(450);
					}
					if (Phase == 3)
					{
						delay_ms(500);
					}
					
					PID_Data_Clear();
					T_S_F0;
					
					delay_ms(1000);
					T_S_L;
					delay_ms(1000);
					
					
					if (Phase == 1)
					{
						Phase = 2;
					}
					if (Phase == 3)
					{
						Phase = 4;
					}
				}
			}
		}
		while(Phase == 2 || Phase == 4)
		{
			Calculate_Angle_Position(Initial_Z,Z);
			if (Phase == 2 && Angle_Difference >= -900)
			{
				T_S_F0;
				PID_Data_Clear();
				Phase  = 3;
				delay_ms(1000);
				T_S_F7;
				delay_ms(1000);
				delay_ms(1000);
			}
			if (Phase == 4 && (Angle_Difference >= -5 && Angle_Difference <= 5))
			{
				T_S_F0;
				PID_Data_Clear();
				Phase  = 0;
				delay_ms(1000);
			}
		}	
	}
	
}

void T_R_P(void)
{
	
	Process = 6;			//右转过程标志
	
	
	uint8_t Phase = 1;
	
	T_S_F7;
	
	
	while(Phase)
	{
		while(Phase == 1 || Phase == 3)
		{
			if ((Grayscale_Sensor_ReadInput() + Grayscale_Sensor_ReadInput_4()) >= 4 )
			{
				delay_ms(10);
				if ((Grayscale_Sensor_ReadInput() + Grayscale_Sensor_ReadInput_4()) >= 4 )
				{
					if (Phase == 1)
					{
						delay_ms(450);
					}
					
					if (Phase == 3)
					{
						delay_ms(580);
					}
					PID_Data_Clear();
					T_S_F0;
					delay_ms(1000);
					T_S_R;
					delay_ms(1000);
					
					
					if (Phase == 1)
					{
						Phase = 2;
					}
					if (Phase == 3)
					{
						Phase = 4;
					}
				}
			}
		}
		while(Phase == 2 || Phase == 4)
		{
			
			Calculate_Angle_Position(Initial_Z,Z);
			if (Phase == 2 && Angle_Difference <= -900)
			{
				PID_Data_Clear();
				T_S_F0;
				Phase  = 3;
				delay_ms(1000);
				T_S_F7;
				delay_ms(1000);
				delay_ms(1000);
			}
			if (Phase == 4 && (Angle_Difference <= -1795 || Angle_Difference >= 1795))
			{
				PID_Data_Clear();
				T_S_F0;
				Phase  = 0;
				delay_ms(1000);
				
				
				
			}
		}	
	}
}

void Adjust_Direction_Turn(void)
{
	uint8_t Adjust_Direction_Flag;
	Calculate_Angle_Position(Initial_Z,Z);
	if (Process == 1 || Process == 3)
	{
		if (Angle_Difference >= -5 && Angle_Difference <= 5){
			Adjust_Direction_Flag = 0;
		}else{
			T_S_F0;
			PID_Data_Clear();
			Adjust_Direction_Flag = 1;
			delay_ms(10);
			Calculate_Angle_Position(Initial_Z,Z);
			
		}
		if (Adjust_Direction_Flag ==1)
		{
			if (Position == 2)
			{
				T_S_R;
			}
			if (Position == 1)
			{
				T_S_L;
			}
		}
	}
	else if (Process == 2 || Process == 4)
	{
		if (Angle_Difference <= -1795 || Angle_Difference >= 1795){
			Adjust_Direction_Flag = 0;
		}else{
			T_S_F0;
			PID_Data_Clear();
			Adjust_Direction_Flag = 1;
			delay_ms(10);
			Calculate_Angle_Position(Initial_Z,Z);
		}
		if (Adjust_Direction_Flag ==1)
		{
			if (Position == 1)
			{
				T_S_R;
			}
			if (Position == 2)
			{
				T_S_L;
			}
		}
	}
	
	if (Process == 2 || Process == 4)
	{
		
		while (Adjust_Direction_Flag)
		{
			Calculate_Angle_Position(Initial_Z,Z);
			if (Angle_Difference <= -1795 || Angle_Difference >= 1795)
			{
			T_S_F0;
			PID_Data_Clear();
			delay_ms(1000);
			Adjust_Direction_Flag = 0;
			}
		}
		
	}
	else if (Process == 1 || Process == 3)
	{
		
		while (Adjust_Direction_Flag)
		{
			Calculate_Angle_Position(Initial_Z,Z);
			if (Angle_Difference >= -5 && Angle_Difference <= 5)
			{
			T_S_F0;
			PID_Data_Clear();
			delay_ms(1000);
			Adjust_Direction_Flag = 0;
			}
		}
		
	}
}


	
void Adjust_Direction()
{
	Calculate_Angle_Position(Initial_Z,Z);
	switch (Process){
		case 0:break;
		case 1://EXTI_DRPS_A();
			break;
		case 2://EXTI_DRPS_B();
			break;
		case 3://EXTI_DRPS_C();
			break;
		case 4://EXTI_DRPS_D();
			break;
		case 5:break;
		case 6:break;
		case 7:break;
	}
}

void Adjust_Direction_Turn_Function(void)
{
	Adjust_Direction_Turn();
	delay_s(2);
	Adjust_Direction_Turn();
	delay_s(2);
	Adjust_Direction_Turn();
}





