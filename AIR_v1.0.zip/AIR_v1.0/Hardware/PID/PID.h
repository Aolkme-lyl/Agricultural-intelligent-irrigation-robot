#ifndef __PID_H__
#define __PID_H__

#include "stdint.h"

extern int16_t Target_Speed1;
extern int16_t Target_Speed2;


extern int16_t Angle_Difference;		//角度差
extern uint8_t Position;				//0：左；1：右


//左轮***********************************************************************************************

extern int16_t L_Kp, L_Ki, L_Kd;					//KP,KI,KD
extern int16_t L_Error, L_LastError;				//期望值与实际值的差, 上一次的差
extern int16_t L_integral, L_integral_limiting;		//积分,积分限幅
extern int16_t L_output, L_output_limiting;			//输出,输出限幅

//###################################################################################################
//右轮***********************************************************************************************

extern int16_t R_Kp, R_Ki, R_Kd;					//KP,KI,KD
extern int16_t R_Error, R_LastError;				//期望值与实际值的差, 上一次的差
extern int16_t R_integral,R_integral_limiting;		//积分,积分限幅
extern int16_t R_output,R_output_limiting;			//输出,输出限幅

//###################################################################################################





void PID_Left_Init(int16_t P, int16_t I,int16_t D, int16_t Integral_limiting, int16_t Output_limiting);
void PID_Right_Init(int16_t P, int16_t I,int16_t D, int16_t Integral_limiting, int16_t Output_limiting);


void Calculate_Angle_Position(int16_t InitialAngle, int16_t SecondAngle);

void PID_calculate_L(int16_t target_value, int16_t actual_value);
void PID_calculate_R(int16_t target_value, int16_t actual_value);

void Go_Adjust(void);

#endif


