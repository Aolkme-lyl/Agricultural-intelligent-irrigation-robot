#include "stm32f10x.h"                  // Device header
#include "initializer.h"				//

int main(void)
{
	Init_All_Devices();					//初始化设备
	
	Program_Run();
	
	
	while(1)
	{
		
	}
}
