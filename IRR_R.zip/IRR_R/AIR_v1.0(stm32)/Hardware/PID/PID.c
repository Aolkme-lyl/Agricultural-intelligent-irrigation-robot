#include "PID.h" 
#include "stm32f10x.h"                  // Device header
#include "imu901.h"
#include "initializer.h"
#include <stdlib.h>


int16_t Target_Speed1;			// 目标左轮速度
int16_t Target_Speed2;			// 目标右轮速度

int counterRight;				//进中断计数控制右轮pwm 
int counterLeft;				//进中断计数控制左轮pwm

int16_t Angle_Difference;		//角度差
uint8_t Position;				//1：右；2：左
//左轮***********************************************************************************************

int16_t L_Kp, L_Ki, L_Kd;						//KP,KI,KD
int16_t L_Error, L_LastError;					//期望值与实际值的差, 上一次的差
int16_t L_integral, L_integral_limiting;		//积分,积分限幅
int16_t L_output, L_output_limiting;			//输出,输出限幅

//###################################################################################################
//右轮***********************************************************************************************

int16_t R_Kp, R_Ki, R_Kd;					//KP,KI,KD
int16_t R_Error, R_LastError;				//期望值与实际值的差, 上一次的差
int16_t R_integral,R_integral_limiting;		//积分,积分限幅
int16_t R_output,R_output_limiting;			//输出,输出限幅

//###################################################################################################


u8 times;														
														
//**************************************************************************************************							
//Pwm_1;				//左前轮
//Pwm_2;				//右前轮
//**************************************************************************************************

void PID_Left_Init(int16_t P, int16_t I,int16_t D, int16_t Integral_limiting, int16_t Output_limiting)
{
	L_Kp = P;
	L_Ki = I;
	L_Kd = D;
	L_integral_limiting = Integral_limiting;
	L_output_limiting = Output_limiting;
}

void PID_Right_Init(int16_t P, int16_t I,int16_t D, int16_t Integral_limiting, int16_t Output_limiting)
{
	R_Kp = P;
	R_Ki = I;
	R_Kd = D;
	R_integral_limiting = Integral_limiting;
	R_output_limiting = Output_limiting;
}


void Calculate_Angle_Position(int16_t InitialAngle, int16_t SecondAngle)
{
	
	
	Angle_Difference = SecondAngle - InitialAngle;
	
	// 将夹角限制在-180度到+180度之间
    if (Angle_Difference > 1800) {
        Angle_Difference -= 3600;
    } else if (Angle_Difference < -1800) {
        Angle_Difference += 3600;
    }
	//判断当前方向是在初始方向的左边还是右边
	if (Angle_Difference == 0){		
		Position = 0;			// 同一角度	
	} else if (Angle_Difference < 0){
		Position = 1;			// 右边
	} else if (Angle_Difference > 0){
		Position = 2;			// 左边
	}
	
}

void PID_calculate_L(int16_t target_value, int16_t actual_value)
{
	int16_t Sp, Si, Sd;
	int16_t Spid;
	
	
	//计算误差
	L_Error = target_value - actual_value; //期望值- 当前值
	
	//比例环节
	Sp = L_Kp * L_Error * 1.0 / 1000;					
	
	//微分环节
	Sd = L_Kd * (L_Error - L_LastError) * 1.0 / 100 ;
	
	//积分环节
	Si = L_Ki * L_Error * 1.0 / 1000;
	L_integral += Si;
	
	//积分限幅
	if (L_integral > L_integral_limiting){
		L_integral = L_integral_limiting;
	}else if(L_integral < -L_integral_limiting){
		L_integral = -L_integral_limiting;
	}
	//计算Spid
	Spid = Sp + Sd + L_integral;
	
	//计算输出
	L_output += Spid ;
	
	//输出限幅
	if (L_output > L_output_limiting){
		L_output = L_output_limiting;
	}else if(L_output < -L_output_limiting){
		L_output = -L_output_limiting;
	}
	
	//误差传递
	L_LastError = L_Error;
	
}

void PID_calculate_R(int16_t target_value, int16_t actual_value)
{
	int16_t Sp, Si, Sd;
	int16_t Spid;
	
	
	//计算误差
	R_Error = target_value - actual_value; //期望值- 当前值
	
	//比例环节
	Sp = R_Kp * R_Error * 1.0 / 1000;					
	
	//微分环节
	Sd = R_Kd * (R_Error - R_LastError) * 1.0 / 100;
	
	//积分环节
	Si = R_Ki * R_Error * 1.0 / 1000;
	R_integral += Si;
	
	//积分限幅
	if (R_integral > R_integral_limiting){
		R_integral = R_integral_limiting;
	}else if(R_integral < -R_integral_limiting){
		R_integral = -R_integral_limiting;
	}
	//计算Spid
	Spid = Sp + Sd + R_integral;
	
	//计算输出
	R_output += Spid ;
	
	//输出限幅
	if (R_output > R_output_limiting){
		R_output = R_output_limiting;
	}else if(R_output < -R_output_limiting){
		R_output = -R_output_limiting;
	}
	
	//误差传递
	R_LastError = R_Error;
	
}




void Go_Adjust(void)
{

	if ((Position == 1) && (Angle_Difference <= -2) && (times == 3))		//方向偏右
	{
		Pwm_2 ++;
		Pwm_4 ++;
		if (Pwm_2 >= 55){
			Pwm_2 = 39;
		}if (Pwm_4 >= 55){
			Pwm_4 = 42;
		}
	}
	if ((Position == 2) && (Angle_Difference >= 2) && (times == 3))		//方向偏右
	{
		Pwm_1 ++;
		Pwm_3 ++;
		if (Pwm_1 >= 50){
			Pwm_1 = 32;
		}if (Pwm_3 >= 50){
			Pwm_3 = 35;
		}
	}
	times ++;
	if (times > 3)
	{
		times = 0;
	}
}


void Go_Straight_PID(void)							//直行PID
{


}

