#include "Spray_Head.h"
#include "initializer.h"
#include "stm32f10x.h"
#include "delay.h"
#include "C_Process.h"



void spray_head_init(void)										//喷水电机的IO口注册
{
	GPIO_InitTypeDef  GPIO_InitStructure;
 	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);		
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	
	GPIO_ResetBits(GPIOE, GPIO_Pin_0 | GPIO_Pin_1);												
}

void L_ONE_Spray(uint8_t ON_OFF)								//左侧单开关
{
	if (ON_OFF == 0){
		GPIO_ResetBits(GPIOE,GPIO_Pin_0);
	}else{
		GPIO_SetBits(GPIOE,GPIO_Pin_0);
	}
}

void R_ONE_Spray(uint8_t ON_OFF)								//右侧单开关
{
	if (ON_OFF == 0){
		GPIO_ResetBits(GPIOE,GPIO_Pin_1);
	}else{
		GPIO_SetBits(GPIOE,GPIO_Pin_1);
	}
}


void Spray_A_and_B(uint8_t number)								//A B 喷水次数
{
	while(number > 0)
	{
		L_O(1); R_O(1);	
		delay_ms(1000);
		L_O(0); R_O(0);		
		delay_ms(700);
		number --;
	}
}
	
void Spray_C_and_D(uint8_t number, uint8_t Left_or_Right_Side)	//C D 喷书次数
{
	if(Left_or_Right_Side == 1)
	{
		while(number > 0)
		{
			L_O(1);
			delay_ms(1000);
			L_O(0); 
			delay_ms(700);
			number --;
		}
	}
	else if(Left_or_Right_Side == 2)
	{
		while(number > 0)
		{
			R_O(1);
			delay_ms(1000);
			R_O(0); 
			delay_ms(700);
			number --;
		}
	}
}






