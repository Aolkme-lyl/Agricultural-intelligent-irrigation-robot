#ifndef __SERVO_H__
#define	__SERVO_H__

extern int16_t Angle_Difference_X;		//角度差
extern uint8_t Position_X;				//1：右；2：左





void Servo_Angle(uint16_t Lpwm, uint16_t Rpwm);						// 舵机设置PWM




void Servo_Angle_Set(uint16_t L_Angle, uint16_t R_Angle);				//角度设置舵机，直立度数为0

void Calculate_Angle_Position_X(int16_t InitialAngle_X, int16_t SecondAngle_X);

void Servo_PWM_Put_Calculation(uint8_t unfinished_or_finished);


void Servo_Angle_Adjust(uint8_t unfinished_or_finished);			// A、B、C、D区舵机调整


#endif



