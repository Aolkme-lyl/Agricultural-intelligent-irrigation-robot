#ifndef __SPRAY_HEAD_H
#define	__SPRAY_HEAD_H
#include "sys.h"

#include "stdint.h"

void spray_head_init(void);						//喷水电机的IO口注册

void L_ONE_Spray(uint8_t ON_OFF);				//左侧单开关
void R_ONE_Spray(uint8_t ON_OFF);				//右侧单开关

void Spray_A_and_B(uint8_t number);				//A 和 B 喷水次数	（左右一块工作）

void Spray_C_and_D(uint8_t number, uint8_t Left_or_Right_Side);	//C D 喷书次数


#define	L_O	 L_ONE_Spray
#define	R_O	 R_ONE_Spray

#endif


