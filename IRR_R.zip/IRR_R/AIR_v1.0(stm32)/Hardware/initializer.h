#ifndef __INITIALIZER_H__
#define __INITIALIZER_H__

/****************************************************************************************
进程/Process:开始阶段为0、A区域为1、B区域为2、C区域为3、D区域为4
				左转弯为5、右转弯为6、结束阶段为7；
Situat[3][6]L:用于存放旱情信息

****************************************************************************************/
#include <stdlib.h> 
#include "stdint.h"						// 定义固定名称
#include "Definition_List.h"			// 定义全局变量文件
#include "Debugs.h"						// Debug
#include "stm32f10x.h"                  // Device header


#include "oled.h"						// OLED显示屏
#include "Voice.h"						// 语音播报
#include "Spray_Head.h"					// 喷头电机
#include "Motor.h"						// 电机驱动控制
#include "Serial.h"						// 串口1
#include "Encoder.h"					// 测试PWM输入
#include "PWM.h"						// PWM输出处理
#include "DRPS.h"						// 光电管中断处理
#include "usart2.h"						// 串口2——
#include "usart3.h"						// 串口3——
#include "imu901.h"						// imu901
#include "Servo.h"						// 舵机调控


#include "Timer.h"						// 定时器 TIM6、7

#include "delay.h" 						// delay函数
#include "Grayscale_Sensor.h"			// 八路灰度传感器


#include "spl_i2c.h"						//I2C通讯
#include "gw_grayscale_sensor.h"		//地址文件
#include "GW_GRAYSCALE_SENSOR_USE.h"	//感为八路灰度管

#include "bool.h"
#include "LobotServoController.h"



#include "Start_Process.h"				// 等待区域
#include "A_Process.h"					// A区域
#include "B_Process.h"					// B区域
#include "C_Process.h"					// C区域
#include "D_Process.h"					// D区域
#include "Turn_Process.h"				// 转弯区域
#include "PID.h"						// PID算法

#include "string.h"						// 字符
#include "stdio.h"
#include <stdarg.h>

#define drps_upside(n) 

//********************************************************************************************
//extern uint16_t Situat[3][6];			//旱情数组
//extern char Situat_A[6];			
//extern char Situat_B[6];
//extern char Situat_C[6];
//extern char Situat_D1[6];
//extern uint8_t Situat_D;				//D区旱情
//extern uint8_t Situat_Dd[6];

//extern int16_t Initial_X;			//初始X
//extern int16_t Initial_Y;			//初始Y
//extern int16_t Initial_Z;			//初始Z

//extern int16_t Pwm_1;				//左前轮
//extern int16_t Pwm_2;				//右前轮

//extern int16_t Pwm_3;				//左舵机
//extern int16_t Pwm_4;				//右舵机

//********************************************************************************************
//extern uint8_t PID_Flag;			//PID执行标识位

/*
extern int16_t A_T_S;				//A区目标速度

extern int16_t B_T_S1;				//B区目标速度1
extern int16_t B_T_S2;				//B区目标速度2

extern int16_t C_T_S;				//C区目标速度

extern int16_t D_T_S1;				//D区目标速度1
extern int16_t D_T_S2;				//D区目标速度2
*/

//********************************************************************************************


void Data_Initialization(void);							//数据初始化函数
void PID_Data_Clear(void);								//PID数据清除函数
void Target_Speed_Set(int16_t L_S, int16_t R_S);		//目标速度设置函数

void Init_All_Devices(void);							//设备初始化
void Program_Run(void);									//运行主函数
		
#define 	T_S_F8		Target_Speed_Set(8, 8)
#define 	T_S_F7		Target_Speed_Set(7, 7)
#define 	T_S_F0		Target_Speed_Set(0, 0)
#define 	T_S_F5		Target_Speed_Set(5, 5)
#define 	T_S_F4		Target_Speed_Set(4, 4)
#define 	T_S_F3		Target_Speed_Set(3, 3)

#define 	T_S_FC		Target_Speed_Set(7, 7)

#define 	T_S_B7		Target_Speed_Set(-7, -7)

#define 	T_S_L		Target_Speed_Set(-5, 5)
#define 	T_S_R		Target_Speed_Set(5, -5)
#define 	D_Clear		PID_Data_Clear()


#endif
