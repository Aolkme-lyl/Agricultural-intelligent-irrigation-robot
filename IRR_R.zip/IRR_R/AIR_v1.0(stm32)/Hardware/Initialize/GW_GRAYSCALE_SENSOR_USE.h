#ifndef __GW_GRAYSCALE_SENSOR_USE_H__
#define __GW_GRAYSCALE_SENSOR_USE_H__

#include "initializer.h"

///* 测试模拟数据改成0, 测试开关量数据改成1 */
//#define GW_READ_DIGITAL_DATA 1


/* 存放扫描到的地址 */
extern uint8_t scan_addr[128];
volatile extern uint8_t count;




/* 读取开关量数据 */
extern uint8_t gray_sensor[8];
extern uint8_t digital_data;


void delay(void);
void spl_i2c_init(void);
uint8_t i2c_scan(uint8_t *scan_addr);

void Reading_function(void);
void Ready_to_scan(void);
#endif




