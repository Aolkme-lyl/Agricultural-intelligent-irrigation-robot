#include "Grayscale_Sensor.h"
#include "stm32f10x.h"                  // Device header
#include "initializer.h"
#include "Serial.h"


uint8_t IO1;
uint8_t IO2;
uint8_t IO3;
uint8_t IO4;
uint8_t IO5;
uint8_t IO6;
uint8_t IO7;
uint8_t IO8;
uint8_t IO9;
uint8_t IO10;
uint8_t IO11;
uint8_t IO12;
uint8_t IO13;
uint8_t IO14;
uint8_t IO15;
uint8_t IO16;

// 定义变量来存储连续为1的IO变量的起始位置和结束位置

int startIdx = -1;
int endIdx = -1;
	


// 普通类型的灰度管 和 带芯片的灰度管

void Grayscale_Sensor_Init_1(void)		//两个四路灰度传感器IO口输入初始化
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;		//PF0 PF1 PF2 PF3
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
}
void Grayscale_Sensor_Init_2(void)		//八路灰度传感器IO口输入初始化
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;		
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;		
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOG, &GPIO_InitStructure);
	
}




int Grayscale_Sensor_ReadInput(void)			//八路IO口状态读取
{
	uint8_t IO = 0;
	
	if (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_6) == 1){
		IO1 = 1;
		IO ++;
	}else{
		IO1 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_7) == 1){
		IO2 = 1;
		IO ++;
	}else{
		IO2 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_8) == 1){
		IO3 = 1;
		IO ++;
	}else{
		IO3 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_9) == 1){
		IO4 = 1;
		IO ++;
	}else{
		IO4 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_6) == 1){
		IO5 = 1;
		IO ++;
	}else{
		IO5 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_7) == 1){
		IO6 = 1;
		IO ++;
	}else{
		IO6 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_8) == 1){
		IO7 = 1;
		IO ++;
	}else{
		IO7 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_9) == 1){
		IO8 = 1;
		IO ++;
	}else{
		IO8 = 0;
	}
	return IO;
}


int Grayscale_Sensor_ReadInput_4(void)			//两个四路IO口状态读取
{
	uint8_t IO = 0;
	
	if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_15) == 1){
		IO9 = 1;
		IO ++;
	}else{
		IO9 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_14) == 1){
		IO10 = 1;
		IO ++;
	}else{
		IO10 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_13) == 1){
		IO11 = 1;
		IO ++;
	}else{
		IO11 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_12) == 1){
		IO12 = 1;
		IO ++;
	}else{
		IO12 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_11) == 1){
		IO13 = 1;
		IO ++;
	}else{
		IO13 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_10) == 1){
		IO14 = 1;
		IO ++;
	}else{
		IO14 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_9) == 1){
		IO15 = 1;
		IO ++;
	}else{
		IO15 = 0;
	}
	if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_8) == 1){
		IO16 = 1;
		IO ++;
	}else{
		IO16 = 0;
	}
	return IO;
}








int Grayscale_Sensor_ReadInput_Analyse(void)	
{
	// 定义一个变量来存储连续为1的计数
	int consecutiveOnes = 0;

	
	
	if (Grayscale_Sensor_ReadInput() >= 2)
	{
		// 遍历IO1到IO8的变量，判断是否有2到4个连续都为1
		for (int i = 1; i <= 8; i++) {
			if (*(uint8_t *)((uintptr_t)&IO1 + i - 1) == 1) {
				consecutiveOnes++;

				if (startIdx == -1) {
					startIdx = i;
				}

				endIdx = i;
			} else {
				consecutiveOnes = 0;
				startIdx = -1;
				endIdx = -1;
			}

			// 判断是否有2到4个连续IO都为1
			if (consecutiveOnes >= 2 && consecutiveOnes <= 4) {
				// 2到4个IO都为1
				// 输出连续为1的IO变量的位置
				for (int j = startIdx; j <= endIdx; j++) {
					// j 表示连续为1的IO变量的位置
					// 执行你的操作或记录位置
				}
			}
		}
	}
	return consecutiveOnes;
}
























