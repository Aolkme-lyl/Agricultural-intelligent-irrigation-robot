#include "stm32f10x.h"                  // Device header
#include "Timer.h"
#include "initializer.h"


uint32_t II,III;

void Timer_Init1(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6,ENABLE);
	
	TIM_InternalClockConfig(TIM6);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
//******************************************************************************
//不可配置	
//	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
//	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
//	TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;	
//******************************************************************************
	TIM_TimeBaseInitStruct.TIM_Period = 1000-1; 			//ARR
	TIM_TimeBaseInitStruct.TIM_Prescaler = 720-1;			//PSC
	
	
	
	TIM_TimeBaseInit(TIM6,&TIM_TimeBaseInitStruct);
	
	TIM_ITConfig(TIM6,TIM_IT_Update,ENABLE);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM6_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM6,ENABLE);
}


void Timer_Init2(void)				
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7,ENABLE);
	
	TIM_InternalClockConfig(TIM7);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
//******************************************************************************
//不可配置	
//	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
//	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
//	TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;	
//******************************************************************************
	TIM_TimeBaseInitStruct.TIM_Period = 1000-1; 			//ARR
	TIM_TimeBaseInitStruct.TIM_Prescaler = 7200-1;			//PSC
	
	
	
	TIM_TimeBaseInit(TIM7,&TIM_TimeBaseInitStruct);
	
	TIM_ITConfig(TIM7,TIM_IT_Update,ENABLE);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM7,ENABLE);
}


void TIM_PID_Function_Speed(void)
{
	Speed_1 = Encoder_Get1();
	II += Speed_1;
	PID_calculate_L(Target_Speed1, Speed_1);
	Motor_L_Set(L_output);
	
	
	Speed_2 = Encoder_Get2();
	III += Speed_2;
	PID_calculate_R(Target_Speed2, Speed_2);
	Motor_R_Set(R_output);
	
}




void TIM6_IRQHandler(void) //PID 计算
{
	if (TIM_GetITStatus(TIM6,TIM_IT_Update) == SET)
	{
		if (PID_Flag == 1)
		{
			TIM_PID_Function_Speed();
		}
		if (Process == 3 )		//跳出C区
		{
			if(Count >= 3){
				if(Grayscale_Sensor_ReadInput() >= 2)
				{
					//printf("%d/%d\r\n",X,Y);
					Process = 5;
					
				}
			}
		}
		//printf("%d,%d\r\n",Speed_1,Speed_2);
		TIM_ClearITPendingBit(TIM6, TIM_IT_Update);
	}
}

void TIM7_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM7,TIM_IT_Update) == SET)
	{
		//printf("%d,%d,%d,%d,%d\r\n",Speed_1,Speed_2,X,Y,Z);
//		if (Process == 3 )
//		{
//			if(Count >= 6){
//				if(((Grayscale_Sensor_ReadInput() >= 7) && (X == 0) && (Y == -1)))
//				{
//					if(Grayscale_Sensor_ReadInput() >= 7)
//					{
//						printf("%d/%d\r\n",X,Y);
//						Process = 5;
//					}
//				}
//			}
//		}	
		
		//printf("%d,%d,%d\r\n",X,Y,Z);
		TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
	}
}



