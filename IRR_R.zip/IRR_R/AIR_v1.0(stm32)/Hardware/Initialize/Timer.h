#ifndef __TIMER_H__
#define __TIMER_H__


void TIM_PID_Function_Speed(void);


void Timer_Init1(void);
void Timer_Init2(void);
//void TIM2_IRQHandler(void);


#endif
