#include "stm32f10x.h"                  // Device header
#include "initializer.h"
#include "PWM.h"  

void Motor_PWM_Init(void)				//电机PWM
 {
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;		//PA2 PA3
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);						//前电机PWM IO口输出

//******************************************************************************	
	TIM_InternalClockConfig(TIM5);				//开启内部时钟
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 1000 - 1;			//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;		//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM5, &TIM_TimeBaseInitStructure);
	
//******************************************************************************
	
	TIM_OCInitTypeDef TIM_OCInitStructure;				//定义结构体

//开启通道3**************************************************************		
	
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;		//CCR
	
	TIM_OC3Init(TIM5, &TIM_OCInitStructure);
	TIM_OC3PreloadConfig(TIM5,TIM_OCPreload_Enable);
	
//开启通道4**************************************************************		
	
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;		//CCR
	
	TIM_OC4Init(TIM5, &TIM_OCInitStructure);
	TIM_OC4PreloadConfig(TIM5,TIM_OCPreload_Enable);
	
	
	TIM_ARRPreloadConfig(TIM5,ENABLE);
	TIM_Cmd(TIM5, ENABLE);					//使能TIM5
		
}


void Servo_PWM_Init(void)				//舵机PWM
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
//	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable , ENABLE);
	
	GPIO_PinRemapConfig(GPIO_PartialRemap2_TIM2,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;	
	
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;		//PA15	 
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//	GPIO_Init(GPIOA, &GPIO_InitStructure);						//舵机PWM IO口输出

	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;		//PB3  PB10 PB11
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);						//舵机PWM IO口输出


//******************************************************************************	
	TIM_InternalClockConfig(TIM2);				//开启内部时钟
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 20000 - 1;		//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;		//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);
	
//******************************************************************************
	
	TIM_OCInitTypeDef TIM_OCInitStructure;				//定义结构体

////开启通道1**************************************************************		
//	
//	TIM_OCStructInit(&TIM_OCInitStructure);
//	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
//	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
//	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
//	TIM_OCInitStructure.TIM_Pulse = 0;		//CCR
//	
//	TIM_OC1Init(TIM2, &TIM_OCInitStructure);
//	TIM_OC1PreloadConfig(TIM2,TIM_OCPreload_Enable);
//	


////开启通道2**************************************************************		
//	
//	TIM_OCStructInit(&TIM_OCInitStructure);
//	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
//	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
//	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
//	TIM_OCInitStructure.TIM_Pulse = 0;		//CCR
//	
//	TIM_OC2Init(TIM2, &TIM_OCInitStructure);
//	TIM_OC2PreloadConfig(TIM2,TIM_OCPreload_Enable);



//开启通道3**************************************************************		
	
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;		//CCR
	
	TIM_OC3Init(TIM2, &TIM_OCInitStructure);
	TIM_OC3PreloadConfig(TIM2,TIM_OCPreload_Enable);
	
//开启通道4**************************************************************		
	
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;		//CCR
	
	TIM_OC4Init(TIM2, &TIM_OCInitStructure);
	TIM_OC4PreloadConfig(TIM2,TIM_OCPreload_Enable);
	
	
	TIM_ARRPreloadConfig(TIM2,ENABLE);
	TIM_Cmd(TIM2, ENABLE);					//使能TIM2
		
}



void Motor_PWM_Set3(uint16_t Compare)
{
	TIM_SetCompare3(TIM5, Compare);
}

void Motor_PWM_Set4(uint16_t Compare)
{
	TIM_SetCompare4(TIM5, Compare);
}


//void Servo_PWM_Set1(uint16_t Compare)
//{
//	TIM_SetCompare1(TIM2, Compare);
//}

//void Servo_PWM_Set2(uint16_t Compare)
//{
//	TIM_SetCompare2(TIM2, Compare);
//}

void Servo_PWM_Set3(uint16_t Compare)
{
	TIM_SetCompare3(TIM2, Compare);
}

void Servo_PWM_Set4(uint16_t Compare)
{
	TIM_SetCompare4(TIM2, Compare);
}


void Motor_PWM_stop(void)	//PWM输出0停止
{
	Motor_PWM_Set3(0);
	Motor_PWM_Set4(0);
}

void Motor_PWM(uint8_t pwm)	//设置PWM值控制车数
{
	Motor_PWM_Set3(pwm);
	Motor_PWM_Set4(pwm);
}

void Motor_ALL_PWM(uint8_t pwm1, uint8_t pwm2)	//设置PWM值控制车数
{
	Motor_PWM_Set3(pwm1);
	Motor_PWM_Set4(pwm2);
}

void Motor_L_Set(int16_t Input_Pwm)
{
	uint16_t Single_PWM;
	if (Input_Pwm >= 0){
		LMF;
		Single_PWM = Input_Pwm;
	}else{
		Single_PWM = -Input_Pwm;
		LMB;
	}
	Motor_PWM_Set3(Single_PWM);
}

void Motor_R_Set(int16_t Input_Pwm)
{
	uint16_t Single_PWM;
	if (Input_Pwm >= 0){
		RMF;
		Single_PWM = Input_Pwm;
	}else{
		Single_PWM = -Input_Pwm;
		RMB;
	}
	Motor_PWM_Set4(Single_PWM);
}


