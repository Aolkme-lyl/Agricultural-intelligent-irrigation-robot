#ifndef __MOTOR_H__
#define __MOTOR_H__
#include "stdint.h"

void Motor_Init(void);

void L_F_M(uint8_t A, uint8_t B);
void R_F_M(uint8_t A, uint8_t B);

void Motor_Forward(void);		//前进
void Motor_Backwards(void);		//后退

void Motor_Stop(void);			//制动停止
void Motor_Disable(void);		//断电停止

void Motor_Right(void);	//右转
void Motor_Left(void);	//左转
	
#define		MF		Motor_Forward()		//前进
#define		MB		Motor_Backwards()	//后退

#define		LMF		L_F_M(1,0)			//左前进
#define		LMB		L_F_M(0,1)			//左后退

#define		RMF		R_F_M(0,1)			//右前进
#define		RMB		R_F_M(1,0)			//右后退


#endif



