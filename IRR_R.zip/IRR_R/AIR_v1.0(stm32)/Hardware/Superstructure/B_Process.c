#include "stm32f10x.h"                  // Device header
#include "initializer.h"
#include "B_Process.h"

uint8_t Flag_B;

void B_Process_Versions_1(void)	
{
	
	Process = 2;				//B区
	Flag_B = 6;
//	Active_B = 1;
//	Active_voice_B = 0;
	if (In_Order_or_Reverse_Order_Flag == 0)
	{
		Count = 0;
	}else if(In_Order_or_Reverse_Order_Flag == 1)
	{
		Count = 5;
	}
									// & :0/5
	Area = 1;
	Voice_Menu(7);					//语音播报
	delay_ms(1000);
	delay_ms(1000);
//	Servo_PWM_Set3(1950);
//	Servo_PWM_Set4(950);
	Adjust_Direction_Turn_Function();
	
							//舵机调整
	T_S_F7;
	delay_ms(1000);
	
	//Adjust_Direction_Turn_Function();
	
	Servo_Angle_Adjust(0);
	
	
	while(Process == 2)
	{
		EXTI_DRPS_B_Versions_1();
		
		if (Flag_B == 0)
		{
			Process = 5;
			T_S_F0;
		}
		delay_ms(10);
	}
	
	
	
}
	


