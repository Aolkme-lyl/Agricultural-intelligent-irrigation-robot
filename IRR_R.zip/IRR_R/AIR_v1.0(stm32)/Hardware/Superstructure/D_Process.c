#include "stm32f10x.h"                  // Device header
#include "initializer.h"
#include "D_Process.h"


uint8_t Flag_D;

uint8_t Situat_D_L;
uint8_t Situat_D_R;

void D_Process_Versions_1(void)			
{
	Flag_D = 6;
	Process = 4;
	Count = 0;
//	Active_D = 0;
	delay_ms(1000);
	Voice_Menu(9);
	delay_ms(1000);
	delay_ms(1000);
	Servo_Angle_Adjust(0);
//	Servo_PWM_Set3(1970);
//	Servo_PWM_Set4(930);
//	Send_To_D();
	Adjust_Direction_Turn_Function();
	delay_ms(1000);
	T_S_F5;
	while(Process == 4 && Flag_D > 0)
	{
		EXTI_DRPS_D_Versions_3();
		if (Flag_D == 0)
		{
			T_S_F0;
		}
	}
	
	
}	

