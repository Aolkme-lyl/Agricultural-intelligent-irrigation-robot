#ifndef __START_PROCESS_H__
#define __START_PROCESS_H__

void Start_Process_Versions_1(void);			//开始阶段函数版本1

void End_Process_Versions_1(void);				//结束阶段函数版本1

//重定义名称方便使用
#define 	S_P_V_1()		Start_Process_Versions_1();
#define 	E_P_V_1()		End_Process_Versions_1();

#endif


