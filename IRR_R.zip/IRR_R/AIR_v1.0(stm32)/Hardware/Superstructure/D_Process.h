#ifndef __D_PROCESS_H__		
#define __D_PROCESS_H__		

#include "stdint.h"

extern uint8_t Flag_D;

extern uint8_t Situat_D_L;
extern uint8_t Situat_D_R;

void D_Process_Versions_1(void);			//区域D

#define 	D_P_V_1()		D_Process_Versions_1()

#endif
