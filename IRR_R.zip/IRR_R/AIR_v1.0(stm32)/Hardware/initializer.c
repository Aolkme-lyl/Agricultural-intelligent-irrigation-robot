#include "stm32f10x.h"                  // Device header
#include "initializer.h"


/****************************************************************************************
Process:开始阶段为0、A区域为1、B区域为2、C区域为3、D区域为4
			左转弯为5、右转弯为6、结束阶段为7；D区倒退阶段8;
			倒退左转10；倒退右转11；
Situat[3][6]L:用于存放旱情信息

****************************************************************************************/
//Situat[3][6] = {{1,1,2,2,2,3},{1,3,2,2,1,3},{1,2,3,2,1,2}};
//Situat_Dd[6] = {3,2,2,1,3,1};

//********************************************************************************************
//********************************************************************************************


	
	
//********************************************************************************************
void Data_Initialization(void)						//各种数据初始化函数
{
	
	
	Process = 0;	Area = 0;	Count = 0;
	IOOROF = 0;				//关于B区是否顺序还是逆序的标识位（0为从上到下从，1为从下到上）
	PID_Flag = 1;			//PID速度环工作标识位（0为失能，1为使能）
	Debug_Flag = 0; 			//是否调试标识位（0为不调试，1为调试）
	
	Target_Speed1 = 0;	Target_Speed2 = 0;			//目标速度为0
	Pwm_3 = 2000;		Pwm_4 = 900; 
	
//	Pwm_D_1_3 = 1970;
//	Pwm_D_1_4 = 930;
//	
	startIdx = -1;
	endIdx = -1;
	

	
	
//	Pwm_D_2_3 = 2050;
//	Pwm_D_2_4 = 800;
	
//PID 参数**********************************************************
	PID_Left_Init(3000,90,3300,4000,800);
	PID_Right_Init(3000,90,3300,4000,800);
		
}

void PID_Data_Clear(void)							//PID数据清除
{
	L_Error = 0;	 	L_LastError = 0;
	L_integral = 0;		L_output = 0; 
	
	R_Error = 0;	 	R_LastError = 0;
	R_integral = 0;		R_output = 0; 
}

void Each_Region_Data_Assignment(uint8_t process)					//各个区域数据赋值
{
	switch(process){
		case 0 : Process = 0;
			break;
		case 1 : Process = 1; Area = 0; Count = 0;
			break;
	
	
	}

}

void Target_Speed_Set(int16_t L_S, int16_t R_S)		//目标速度设置
{
	Target_Speed1 = L_S;	Target_Speed2 = R_S;


//	L_Kp = 0; 	L_Ki = 0;	 L_Kd = 0;				
//	L_Error = 0;	 	L_LastError = 0;			
//	L_integral = 0;		L_integral_limiting = 0;	
//	L_output = 0; 		L_output_limiting = 0;	

//	R_Kp = 0;	R_Ki = 0;	 R_Kd = 0;				
//	R_Error = 0; 		R_LastError = 0;			
//	R_integral = 0;		R_integral_limiting = 0;	
//	R_output = 0;		R_output_limiting = 0;	
	
}
//********************************************************************************************

void Init_All_Devices(void)							//初始化项目
{
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//中断分组
	Serial_Init();									//串口通讯初始化

	Voice_Init();									//VOICE 注册
	delay_init();									//delay 注册
	OLED_Init();									//OLED初始化
	Motor_Init();									//控制前进和后退的IO口初始化
	spray_head_init();								//喷头初始化
	Motor_PWM_Init();								//输出PWM波输出初始化
	Servo_PWM_Init();								//舵机PWM波输出初始化
	
	Grayscale_Sensor_Init_1();						//8路（两个4路）灰度初始化
	Grayscale_Sensor_Init_2();						//8路灰度初始化
	Drps_Init_Open();								//上层光电管
	Drps_Init_Open2();								//下层光电管
	
	//Drps_Init_Open3();							//待使用光电管
	
	USART2_init(115200);							//串口2初始化——imu901 陀螺仪
	
	Serial3_Init();
	
	
	//Timer_Init1();								//定时器中断开启初始化
	
	//Serial3_Init();
	//OLED_ShowString(1,1,"IRR");					//第一行显示；
	Encoder_Init1();								//左测速
	Encoder_Init2();								//右测速
	
//	GW_READ_DIGITAL_DATA_CONFIG();					//灰度管开启
//	Ready_to_scan();
	
}

void Program_Run(void)								//主运行函数
{
	int16_t S1 = 0, S2 = 0;
	Data_Initialization();
//	printf("%d\r\n",X);
	Timer_Init1();
	//Debug_Flag = 0;
	if (Debug_Flag == 0)									//是否调试标识位（0为不调试，1为调试）
	{
		S_P_V_1();						//Start
		A_P_V_1();						//A
		T_R_P();						//R
		
		B_P_V_1();						//B
		T_L_P();
		
		C_P_V_1();
		T_R_P();
		
		D_P_V_1();
		E_P_V_1();
	}
	else if(Debug_Flag == 1)
	{
		Debugging_Program_1();
	
	}
	
	
//	Servo_PWM_Set3(2050);
//	Servo_PWM_Set4(800);
//	Timer_Init1();
//	Timer_Init2();
//	L_O(1); R_O(1); L_T(1); R_T(1);
//	while(1){
//		L_O(1); R_O(1);
//		delay_ms(500);
//		delay_ms(1000);
//		delay_ms(1000);
//		L_O(0); R_O(0);
//		L_T(1); R_T(1);
//		delay_ms(500);
//		delay_ms(1000);
//		delay_ms(1000);
//		L_T(0); R_T(0);
//		L_O(1); R_O(1);
//		//L_T(1); 
//		R_T(1);
//		delay_ms(500);
//		delay_ms(1000);
//		delay_ms(1000);
//		L_O(0); R_O(0);
//		L_T(0); R_T(0);	
//	}
	
//	S_P();
//	A_P();
//	T_R_P();
//	B_P();
//	T_L_P();
//	C_P();
//	T_R_P();
//	D_P();
//	SS_P();
//	Target_Speed1 = 0;	Target_Speed2 = 0;
//	delay_ms(500);
//	delay_ms(1000);
//	delay_ms(100);
//	
//	Initial_X = X;
//	Initial_Y = Y;
//	Initial_Z = Z;
//	printf("%d/%d/%d\r\n",Initial_X,Initial_Y,Initial_Z);
//	T_R_P();
//	T_S_F7;
	//uint8_t i = 1;
	while(1)
	{
		
		//A1 = 0;
//		printf("%d\r\n",X);
//		Voice_Menu(4);
//		printf("%d/33\r\n",Situat_D);
//		Send_L_Openmv();
//		Servo_PWM_Set3(Pwm_D_2_3);
//		delay_ms(500);
		delay_ms(1000);
//		printf("%d/33\r\n",Situat_D);
		delay_ms(1000);
		
//		Servo_PWM_Set3(Pwm_D_1_3);
//		delay_ms(500);
//		delay_ms(1000);
//		delay_ms(1000);
//		i++;
//		if (i == 11)
//		{
//			i = 1;
//		}
//		
		
//		A1 = 1;
//		Voice_Menu(10);
//		
//		delay_ms(500);
//		delay_ms(1000);
//		delay_ms(1000);
//		Voice_Menu(11);
//		
//		delay_ms(500);
//		delay_ms(1000);
//		delay_ms(1000);

	}

}
//		Target_Speed1 = 7;	Target_Speed2 = 7;
//		delay_ms(1000);
//		delay_ms(1000);
//		delay_ms(1000);
//		Target_Speed1 = 0;	Target_Speed2 = 0;
//		delay_ms(1000);
//		delay_ms(1000);
//		delay_ms(1000);
//		MF;
//		Motor_PWM(20);
		
//		S1 =  Encoder_Get1();
//		S2 =  Encoder_Get2();
//		printf("%d/%d\r\n",S1,S2);
//		delay_ms(80);






