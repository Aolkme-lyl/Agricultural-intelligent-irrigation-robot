# Untitled - By: 徐少恒 - 周一 8月 7 2023

import sensor, image, time,pyb
from pyb import Pin, Timer
import time
from pyb import UART

uart = UART(1, 9600)
led = pyb.LED(3)


red_threshold   =(0, 100, 8, 127, 5, 127)
blue_threshold =(0, 100, -128, 127, -128, -18)
green_threshold =(0, 100, -128, -22, -128, 127)



data1=0X5B
data2=0X5B
color1=4
color2=4
color3=4
color4=4
color5=4
color6=4
color7=4
color8=4
color9=4
color10=4
color11=4
color12=4
color13=4
color14=4
color15=4
color16=4
color17=4
color18=4
data3=0xB3
Colors =[data1,data2,color1,color2,color3,color4,color5,color6,color7,color8,color9,color10,color11,color12,color13,color14,color15,color16,color17,color18,data3]

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_whitebal(False)
sensor.set_auto_gain(False)

roi=()

def Color_Judje(Colorx_l,Colorx_a,Colorx_b):
        if Colorx_l>=red_threshold[0] and Colorx_l<=red_threshold[1]:
            if Colorx_a>=red_threshold[2] and Colorx_a<=red_threshold[3]:
                if Colorx_b>=red_threshold[4] and Colorx_b<=red_threshold[5]:
                    print("红色")
                    return 3
        if Colorx_l>=blue_threshold[0] and Colorx_l<=blue_threshold[1]:
            if Colorx_a>=blue_threshold[2] and Colorx_a<=blue_threshold[3]:
                if Colorx_b>=blue_threshold[4] and Colorx_b<=blue_threshold[5]:
                    print("蓝色")
                    return 2
        if Colorx_a>=green_threshold[2] and Colorx_a<=green_threshold[3]:
            if Colorx_l>=green_threshold[0] and Colorx_l<=green_threshold[1]:
                if Colorx_b>=green_threshold[4] and Colorx_b<=green_threshold[5]:
                    print("绿色")
                    return 1
        else:
            print("未检测到颜色")
            return 4

def Uart_Lora():
    global Flag
    write_str='@'
    for i in range(2,20):
        write_str+=str(Colors[i])
    write_str=write_str+'\r\n'
    uart.write(write_str)
    print(write_str)

clock = time.clock()

while(True):
    clock.tick()
    img = sensor.snapshot().lens_corr(0.95)
    blobs =img.find_blobs([red_threshold,blue_threshold,green_threshold],pixels_threshold=1000,area_threshold=1000,merge=True,margin=30)
    if blobs:
        for blob in blobs:
            x = blob[0]+15
            y = blob[1]
            width = blob[2]-20
            hight = blob[3]
            center_x = blob[5]
            center_y = blob[6]
            color_code = blob[8]
            w_middle = int(width/3)
            h_middle=int(hight/6)
            ROI1=[x-5,y,w_middle-20,h_middle]
            ROI2=[x-5,y+h_middle,w_middle-20,h_middle]
            ROI3=[x-5,y+h_middle*2,w_middle-20,h_middle]
            ROI4=[x-5,y+h_middle*3,w_middle-20,h_middle]
            ROI5=[x-5,y+h_middle*4,w_middle-20,h_middle]
            ROI6=[x-5,y+h_middle*5,w_middle-20,h_middle]
            ROI7=[x+w_middle,y,w_middle-20,h_middle]
            ROI8=[x+w_middle,y+h_middle,w_middle-20,h_middle]
            ROI9=[x+w_middle,y+h_middle*2,w_middle-20,h_middle]
            ROI10=[x+w_middle,y+h_middle*3,w_middle-20,h_middle]
            ROI11=[x+w_middle,y+h_middle*4,w_middle-20,h_middle]
            ROI12=[x+w_middle,y+h_middle*5,w_middle-20,h_middle]
            ROI13=[x+w_middle*2+10,y,w_middle-20,h_middle]
            ROI14=[x+w_middle*2+10,y+h_middle,w_middle-20,h_middle]
            ROI15=[x+w_middle*2+10,y+h_middle*2,w_middle-20,h_middle]
            ROI16=[x+w_middle*2+10,y+h_middle*3,w_middle-20,h_middle]
            ROI17=[x+w_middle*2+10,y+h_middle*4,w_middle-20,h_middle]
            ROI18=[x+w_middle*2+10,y+h_middle*5,w_middle-20,h_middle]
            img.draw_rectangle(ROI1)
            img.draw_rectangle(ROI2)
            img.draw_rectangle(ROI3)
            img.draw_rectangle(ROI4)
            img.draw_rectangle(ROI5)
            img.draw_rectangle(ROI6)
            img.draw_rectangle(ROI7)
            img.draw_rectangle(ROI8)
            img.draw_rectangle(ROI9)
            img.draw_rectangle(ROI10)
            img.draw_rectangle(ROI11)
            img.draw_rectangle(ROI12)
            img.draw_rectangle(ROI13)
            img.draw_rectangle(ROI14)
            img.draw_rectangle(ROI15)
            img.draw_rectangle(ROI16)
            img.draw_rectangle(ROI17)
            img.draw_rectangle(ROI18)
            img.draw_cross(center_x,center_y)
            statistics1=img.get_statistics(roi=ROI1)
            statistics2=img.get_statistics(roi=ROI2)
            statistics3=img.get_statistics(roi=ROI3)
            statistics4=img.get_statistics(roi=ROI4)
            statistics5=img.get_statistics(roi=ROI5)
            statistics6=img.get_statistics(roi=ROI6)
            statistics7=img.get_statistics(roi=ROI7)
            statistics8=img.get_statistics(roi=ROI8)
            statistics9=img.get_statistics(roi=ROI9)
            statistics10=img.get_statistics(roi=ROI10)
            statistics11=img.get_statistics(roi=ROI11)
            statistics12=img.get_statistics(roi=ROI12)
            statistics13=img.get_statistics(roi=ROI13)
            statistics14=img.get_statistics(roi=ROI14)
            statistics15=img.get_statistics(roi=ROI15)
            statistics16=img.get_statistics(roi=ROI16)
            statistics17=img.get_statistics(roi=ROI17)
            statistics18=img.get_statistics(roi=ROI18)
            Color1_l=statistics1.l_mode()
            Color1_a=statistics1.a_mode()
            Color1_b=statistics1.b_mode()
            Color2_l=statistics2.l_mode()
            Color2_a=statistics2.a_mode()
            Color2_b=statistics2.b_mode()
            Color3_l=statistics3.l_mode()
            Color3_a=statistics3.a_mode()
            Color3_b=statistics3.b_mode()
            Color4_l=statistics4.l_mode()
            Color4_a=statistics4.a_mode()
            Color4_b=statistics4.b_mode()
            Color5_l=statistics5.l_mode()
            Color5_a=statistics5.a_mode()
            Color5_b=statistics5.b_mode()
            Color6_l=statistics6.l_mode()
            Color6_a=statistics6.a_mode()
            Color6_b=statistics6.b_mode()
            Color7_l=statistics7.l_mode()
            Color7_a=statistics7.a_mode()
            Color7_b=statistics7.b_mode()
            Color8_l=statistics8.l_mode()
            Color8_a=statistics8.a_mode()
            Color8_b=statistics8.b_mode()
            Color9_l=statistics9.l_mode()
            Color9_a=statistics9.a_mode()
            Color9_b=statistics9.b_mode()
            Color10_l=statistics10.l_mode()
            Color10_a=statistics10.a_mode()
            Color10_b=statistics10.b_mode()
            Color11_l=statistics11.l_mode()
            Color11_a=statistics11.a_mode()
            Color11_b=statistics11.b_mode()
            Color12_l=statistics12.l_mode()
            Color12_a=statistics12.a_mode()
            Color12_b=statistics12.b_mode()
            Color13_l=statistics13.l_mode()
            Color13_a=statistics13.a_mode()
            Color13_b=statistics13.b_mode()
            Color14_l=statistics14.l_mode()
            Color14_a=statistics14.a_mode()
            Color14_b=statistics14.b_mode()
            Color15_l=statistics15.l_mode()
            Color15_a=statistics15.a_mode()
            Color15_b=statistics15.b_mode()
            Color16_l=statistics16.l_mode()
            Color16_a=statistics16.a_mode()
            Color16_b=statistics16.b_mode()
            Color17_l=statistics17.l_mode()
            Color17_a=statistics17.a_mode()
            Color17_b=statistics17.b_mode()
            Color18_l=statistics18.l_mode()
            Color18_a=statistics18.a_mode()
            Color18_b=statistics18.b_mode()
            Colors[2]=Color_Judje(Color1_l,Color1_a,Color1_b)
            print(Colors[2])
            Colors[3]=Color_Judje(Color2_l,Color2_a,Color2_b)
            print(Colors[3])
            Colors[4]=Color_Judje(Color3_l,Color3_a,Color3_b)
            print(Colors[4])
            Colors[5]=Color_Judje(Color4_l,Color4_a,Color4_b)
            print(Colors[5])
            Colors[6]=Color_Judje(Color5_l,Color5_a,Color5_b)
            print(Colors[6])
            Colors[7]=Color_Judje(Color6_l,Color6_a,Color6_b)
            print(Colors[7])


            Colors[8]=Color_Judje(Color7_l,Color7_a,Color7_b)
            print(Colors[8])
            Colors[9]=Color_Judje(Color8_l,Color8_a,Color8_b)
            print(Colors[9])
            Colors[10]=Color_Judje(Color9_l,Color9_a,Color9_b)
            print(Colors[10])
            Colors[11]=Color_Judje(Color10_l,Color10_a,Color10_b)
            print(Colors[11])
            Colors[12]=Color_Judje(Color11_l,Color11_a,Color11_b)
            print(Colors[12])
            Colors[13]=Color_Judje(Color12_l,Color12_a,Color12_b)
            print(Colors[13])


            Colors[14]=Color_Judje(Color13_l,Color13_a,Color13_b)
            print(Colors[14])
            Colors[15]=Color_Judje(Color14_l,Color14_a,Color14_b)
            print(Colors[15])
            Colors[16]=Color_Judje(Color15_l,Color15_a,Color15_b)
            print(Colors[16])
            Colors[17]=Color_Judje(Color16_l,Color16_a,Color16_b)
            print(Colors[17])
            Colors[18]=Color_Judje(Color17_l,Color17_a,Color17_b)
            print(Colors[18])
            Colors[19]=Color_Judje(Color18_l,Color18_a,Color18_b)
            print(Colors[19])


            print(Colors)
            if Colors[2]!=None and Colors[3]!=None and Colors[4]!=None and Colors[5]!=None and Colors[6]!=None and Colors[7]!=None :
               if Colors[8]!=None and Colors[9]!=None and Colors[10]!=None and Colors[11]!=None and Colors[12]!=None and Colors[13]!=None :
                   if Colors[14]!=None and Colors[15]!=None and Colors[16]!=None and Colors[17]!=None and Colors[18]!=None and Colors[19]!=None :
                      # Data = bytearray(Colors)
                      # print("传输：{}".format(Data))
                      # print("传输成功！！！")
                       if uart.any():
                           a=uart.read(8).decode()
                           if a=="1":
                               Uart_Lora()
                               led.on()
                               time.sleep_ms(100)
                               led.off()
                               time.sleep_ms(100)
                               print(clock.fps())



